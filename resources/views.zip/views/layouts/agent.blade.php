@extends('layouts.app')

@section('content')
@yield('agent-content')
@endsection
