@extends('layouts.app')

@section('content')
@yield('admin-content')
@endsection
