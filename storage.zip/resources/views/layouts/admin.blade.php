@extends('layouts.app')

@section('content')
<div class="main-content">
    @yield('admin-content')
</div>
@endsection
