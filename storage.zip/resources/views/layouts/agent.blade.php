@extends('layouts.app')

@section('content')
<div class="main-content">
    @yield('agent-content')
</div>
@endsection
