

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<div class="notifications-container">
    <!-- Header -->
    <div class="page-header d-flex justify-content-between align-items-center mb-4">
        <h1 class="page-title">
            <i class="fa fa-bell me-2"></i> Agent Notifications
        </h1>
        <form action="<?php echo e(route('agent.notifications.markAll')); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <button class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
                <i class="fa fa-check-double"></i> Mark All as Read
            </button>
        </form>
    </div>

    <?php if(session('status')): ?>
    <div class="alert alert-success mb-4"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <?php if($notifications->count()): ?>
    <?php
    $messages = [];
    $otherNotifications = [];

    foreach($notifications as $notification) {
    $data = (array) ($notification->data ?? []);
    if(($data['type'] ?? '') === 'application_message_added') {
    $messages[] = $notification;
    } else {
    $otherNotifications[] = $notification;
    }
    }

    $typeTitles = [
    'application_status' => 'Application Status Updated',
    'student_status' => 'Student Status Updated',
    'other' => 'Other Notifications',
    ];

    $grouped = collect($otherNotifications)->groupBy(fn($n) => ($n->data['type'] ?? 'other'));
    ?>

    <div class="notifications-grid d-flex gap-4">
        <!-- Main Notifications (Left) -->
        <div class="flex-grow-1">
            <?php $__empty_1 = true; $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $notificationsOfType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mb-5">
                <h4 class="section-title d-flex align-items-center">
                    <i class="fa <?php echo e(match($type) {
                                'application_status' => 'fa-file-circle-check',
                                'student_status' => 'fa-user-check',
                                default => 'fa-bell',
                            }); ?> me-2"></i>
                    <?php echo e($typeTitles[$type] ?? ucfirst(str_replace('_', ' ', $type))); ?>

                    <span class="text-muted ms-auto">(<?php echo e($notificationsOfType->count()); ?>)</span>
                </h4>

                <?php $__currentLoopData = $notificationsOfType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $isUnread = is_null($notification->read_at);
                $data = (array) ($notification->data ?? []);
                $message = $data['message'] ?? $data['title'] ?? $data['body'] ?? 'Notification';
                $created = $notification->created_at?->diffForHumans();
                $short = $data['short'] ?? $data['details'] ?? null;

                $url = $data['link'] ?? $data['url'] ?? null;
                if (!$url && !empty($data['application_id'])) {
                $url = route('agent.applications.show', $data['application_id']);
                if (!empty($data['comment_id'])) {
                $url .= '#comment-' . $data['comment_id'];
                }
                } elseif (!$url && !empty($data['student_id'])) {
                $url = route('agent.students.show', $data['student_id']);
                }

                $icon = match($type) {
                'application_status' => 'fa-file-circle-check',
                'student_status' => 'fa-user-check',
                default => 'fa-bell',
                };
                ?>

                <div class="notification-card mb-2 p-3 d-flex align-items-start border rounded <?php echo e($isUnread ? 'bg-light' : ''); ?>">
                    <div class="notification-icon me-3">
                        <i class="fa <?php echo e($icon); ?> fa-2x"></i>
                    </div>

                    <div class="notification-body flex-grow-1">
                        <p class="notification-title mb-1"><?php echo $message; ?></p>
                        <?php if($short): ?>
                        <p class="notification-text"><?php echo e(Str::limit($short, 130)); ?></p>
                        <?php endif; ?>
                        <small class="text-muted">
                            <i class="fa fa-clock me-1"></i><?php echo e($created); ?>

                            <?php if($isUnread): ?><span class="badge bg-primary ms-2">New</span><?php endif; ?>
                        </small>
                    </div>

                    <div class="notification-actions ms-3" onclick="event.stopPropagation();">
                        <?php if($isUnread): ?>
                        <form action="<?php echo e(route('agent.notifications.markAsRead', $notification->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-success" title="Mark as read">
                                <i class="fa fa-check"></i>
                            </button>
                        </form>
                        <?php else: ?>
                        <form action="<?php echo e(route('agent.notifications.markUnread', $notification->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-secondary" title="Mark as unread">
                                <i class="fa fa-undo"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state text-center py-4">
                <i class="fa fa-bell-slash fa-2x mb-2"></i>
                <p>No notifications in this category.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Messages Sidebar (Right) -->
        <div style="width: 300px;">
            <h4 class="mb-3"><i class="fa fa-envelope me-1"></i> Messages
                <?php if(count($messages)): ?>
                <span class="text-muted ms-auto">(<?php echo e(count($messages)); ?>)</span>
                <?php endif; ?>
            </h4>

            <?php if(count($messages)): ?>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $isUnread = is_null($notification->read_at);
            $data = (array) $notification->data;
            $sender = $data['added_by']['name'] ?? 'Unknown';
            $message = $data['message'] ?? 'No message';
            $created = $notification->created_at?->diffForHumans();
            $url = $data['link'] ?? null;
            ?>
            <div class="notification-card mb-2 p-2 border rounded <?php echo e($isUnread ? 'bg-light' : ''); ?>">
                <p class="mb-1"><?php echo $message; ?></p>
                <small class="text-muted"><?php echo e($created); ?> | By: <?php echo e($sender); ?></small>
                <div class="mt-1">
                    <?php if($isUnread): ?>
                    <form action="<?php echo e(route('agent.notifications.markAsRead', $notification->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-outline-success">Mark as Read</button>
                    </form>
                    <?php else: ?>
                    <form action="<?php echo e(route('agent.notifications.markUnread', $notification->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-outline-secondary">Mark as Unread</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="empty-state text-center py-4">
                <i class="fa fa-envelope-open fa-2x mb-2"></i>
                <p>No messages yet.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Pagination -->
    <div class="mt-5 d-flex justify-content-center">
        <?php echo e($notifications->links()); ?>

    </div>
    <?php else: ?>
    <div class="section-card text-center py-6">
        <div class="empty-state">
            <i class="fa fa-bell-slash"></i>
            <p class="mb-0 mt-3">No notifications yet. You're all caught up!</p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\agent\notifications.blade.php ENDPATH**/ ?>