

<?php $__env->startSection('content'); ?>
<div class="container p-4">

    
    <div class="card shadow-lg border-0 mb-5">
        <div class="card-body p-4 d-flex justify-content-between align-items-center">
            <div>
                <h2 class="fw-bold mb-2">
                    <i class="fas fa-university text-primary me-2"></i>
                    <?php echo e($university->name); ?>

                    <small class="text-muted">(<?php echo e($university->short_name ?? 'N/A'); ?>)</small>
                </h2>
                <p class="mb-1"><i class="fas fa-globe-asia text-secondary me-2"></i><strong>Country:</strong> <?php echo e($university->country); ?></p>
                <p class="mb-1"><i class="fas fa-city text-secondary me-2"></i><strong>City:</strong> <?php echo e($university->city ?? 'N/A'); ?></p>
                <p class="mb-1"><i class="fas fa-envelope text-secondary me-2"></i><strong>Email:</strong> <?php echo e($university->contact_email ?? 'N/A'); ?></p>
                <p class="mb-1"><i class="fas fa-link text-secondary me-2"></i><strong>Website:</strong>
                    <a href="<?php echo e($university->website); ?>" target="_blank"><?php echo e($university->website); ?></a>
                </p>
                <p class="mt-3 text-muted"><i class="fas fa-info-circle text-secondary me-2"></i><?php echo e($university->description ?? 'No description available.'); ?></p>
            </div>

            <div class="text-center">
                <?php if($university->university_logo): ?>
                <img src="<?php echo e(asset('storage/uni_logo/' . $university->university_logo)); ?>" alt="Logo" class="img-fluid rounded shadow-sm" style="max-height: 120px;">
                <?php else: ?>
                <div class="bg-light text-muted p-4 rounded">
                    <i class="fas fa-university fa-3x"></i>
                    <p class="mt-2 small">No Logo</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="m-1">
        <h3 class="fw-bold mb-3">
            <i class="fas fa-book-open text-secondary me-2"></i> Courses Offered
        </h3>

        <?php if($university->courses->count()): ?>
        <div class="table-responsive">
            <table class="table table-hover table-striped align-middle shadow-sm">
                <thead class="table-dark">
                    <tr>
                        <th><i class="fas fa-hashtag me-1"></i> Code</th>
                        <th><i class="fas fa-book me-1"></i> Title</th>
                        <th><i class="fas fa-clock me-1"></i> Duration</th>
                        <th><i class="fas fa-dollar-sign me-1"></i> Fee</th>
                        <th><i class="fas fa-calendar-alt me-1"></i> Intakes</th>
                        <th><i class="fas fa-language me-1"></i> MOI Requirement</th>
                        <th><i class="fas fa-graduation-cap me-1"></i> Scholarships</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $university->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($course->course_code); ?></td>
                        <td><?php echo e($course->title); ?></td>
                        <td><?php echo e($course->duration); ?></td>
                        <td><?php echo e($course->fee); ?></td>
                        <td><?php echo e($course->intakes); ?></td>
                        <td><?php echo e($course->moi_requirement); ?></td>
                        <td><?php echo e($course->scholarships); ?> </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="alert alert-info">
            <i class="fas fa-exclamation-circle me-2"></i> No courses found for this university.
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\guest\universities\show.blade.php ENDPATH**/ ?>