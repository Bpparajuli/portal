<?php $__env->startSection('content'); ?>
<div class="p-3">
    <?php if(auth()->check() && auth()->user()->is_admin): ?>
    <h2 class="text-center mb-4">Users Waiting for Approval</h2>

    <?php if($users->isEmpty()): ?>
    <div class="alert alert-info text-center">No users waiting for approval.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered align-middle text-center">
            <thead class="table-dark">
                <tr>
                    <th>Logo</th>
                    <th>Business Name</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($user->business_logo): ?>
                        <img src="<?php echo e(Storage::url($user->business_logo)); ?>" alt="Logo" width="60" height="60" class="rounded-circle">
                        <?php else: ?>
                        <span class="text-muted">No Logo</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->business_name); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->contact); ?></td>
                    <td><?php echo e($user->address); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.users.approve', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit" class="btn btn-success btn-sm">Approve</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="alert alert-danger text-center mt-5">
        You are not authorized to view this page.
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\users\waiting.blade.php ENDPATH**/ ?>