<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid p-4">
    <div class="page-header">
        <h2>All Users</h2>
        <a href="<?php echo e(route('admin.users.create') ?? '#'); ?>" class="add-btn">
            <i class="fas fa-user-plus me-2"></i> Add User
        </a>
    </div>

    
    <form method="GET" action="<?php echo e(route('admin.users.index')); ?>">
        <div class="filter-bar">
            <input type="text" name="search" value="<?php echo e($search ?? ''); ?>" placeholder="Search by name, email, or business...">
            <select name="role">
                <option value="">All Roles</option>
                <option value="admin" <?php echo e(request('role') === 'admin' ? 'selected' : ''); ?>>Admins</option>
                <option value="agent" <?php echo e(request('role') === 'agent' ? 'selected' : ''); ?>>Agents</option>
            </select>
            <button type="submit"><i class="fas fa-search me-1"></i> Filter</button>
        </div>
    </form>

    
    <?php if(auth()->id() === 1): ?>
    <?php if($admins->count()): ?>
    <div class="card-section">
        <h4>Admins</h4>
        <div class="table-responsive">
            <table class=" table table-striped align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Logo</th>
                        <th>Business</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $admin->id)); ?>" class="text-decoration-none">
                                <?php echo e($admin->id); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $admin->id)); ?>">
                                <?php if($admin->business_logo): ?>
                                <img src="<?php echo e(Storage::url($admin->business_logo)); ?>" alt="Logo" width="50" height="50" class="rounded-circle">
                                <?php else: ?>
                                <span class="text-muted">No Logo</span>
                                <?php endif; ?>
                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $admin->id)); ?>" class="text-decoration-none fw-semibold">
                                <?php echo e($admin->business_name); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $admin->id)); ?>" class="text-decoration-none">
                                <?php echo e($admin->name); ?>

                            </a>
                        </td>
                        <td><?php echo e($admin->email); ?></td>
                        <td><span class="badge <?php echo e($admin->active ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($admin->active ? 'Active' : 'Inactive'); ?></span></td>
                        <td>
                            <a href="<?php echo e(route('admin.users.edit', $admin->id)); ?>" class="btn btn-light btn-sm"><i class="fa fa-edit"></i></a>
                            <?php if(auth()->id() === 1 && $admin->id !== 1): ?>
                            <form action="<?php echo e(route('admin.users.destroy', $admin->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($admins->links()); ?>

    </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php if($agents->count()): ?>
    <div class="card-section">
        <h4>Agents</h4>
        <div class="table-responsive">
            <table class=" table table-striped align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Logo</th>
                        <th>Business</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Status</th>
                        <th>Students</th>
                        <th>Applications</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $agent->id)); ?>" class="text-decoration-none">
                                <?php echo e($agent->id); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $agent->id)); ?>">
                                <?php if($agent->business_logo): ?>
                                <img src="<?php echo e(Storage::url($agent->business_logo)); ?>" alt="Logo" width="45" height="45" class="rounded-3">
                                <?php else: ?>
                                <span class="text-muted">No Logo</span>
                                <?php endif; ?>
                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $agent->id)); ?>" class="text-decoration-none fw-semibold">
                                <?php echo e($agent->business_name); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $agent->id)); ?>" class="text-decoration-none">
                                <?php echo e($agent->name); ?>

                            </a>
                        </td>
                        <td><?php echo e($agent->email); ?><br><small><?php echo e($agent->contact); ?></small></td>
                        <td><span class="badge <?php echo e($agent->active ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($agent->active ? 'Active' : 'Inactive'); ?></span></td>
                        <td><a href="<?php echo e(route('admin.users.students', $agent->id)); ?>" class="btn btn-info btn-sm"><?php echo e($agent->students_count); ?></a></td>
                        <td><a href="<?php echo e(route('admin.users.applications', $agent->id)); ?>" class="btn btn-secondary btn-sm"><?php echo e($agent->applications_count); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('admin.users.edit', $agent->id)); ?>" class="btn btn-secondary btn-sm"><i class="fa fa-edit"></i></a>
                            <?php if(auth()->id() === 1): ?>
                            <form action="<?php echo e(route('admin.users.destroy', $agent->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($agents->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/admin/users/index.blade.php ENDPATH**/ ?>