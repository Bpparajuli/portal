<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name','label','required'=>false,'value'=>null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name','label','required'=>false,'value'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="mb-3 file-upload-group">
    <label for="<?php echo e($name); ?>" class="form-label fw-semibold"><?php echo e($label); ?></label>
    
    <?php if($value): ?>
    <?php
    $extension = pathinfo($value, PATHINFO_EXTENSION);
    ?>
    <div class="file-preview border rounded p-2 mb-2 d-flex align-items-center gap-3 bg-light">
        <a href="#" class="preview-link" data-preview="<?php echo e(asset('storage/' . $value)); ?>">
            <?php if(in_array(strtolower($extension), ['jpg','jpeg','png','gif'])): ?>
            <img src="<?php echo e(asset('storage/' . $value)); ?>" style="width:70px; height:70px; object-fit:cover; border-radius:6px;">
            <?php elseif(strtolower($extension) === 'pdf'): ?>
            <i class="bi bi-file-earmark-pdf text-danger fs-2"></i>
            <?php else: ?>
            <i class="bi bi-file-earmark fs-2 text-secondary"></i>
            <?php endif; ?>
        </a>
        <div>
            <p class="mb-1"><strong><?php echo e(basename($value)); ?></strong></p>
            <small class="text-muted"><?php echo e(strtoupper($extension)); ?> file</small>
        </div>
    </div>
    <?php endif; ?>

    
    <input type="file" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" <?php echo e($required ? 'required' : ''); ?> <?php echo e($attributes->merge(['class' => 'form-control file-input'])); ?> accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif">

    
    <div class="live-preview mt-2"></div>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="text-danger small"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\laragon\www\portal\resources\views\components\form\file.blade.php ENDPATH**/ ?>