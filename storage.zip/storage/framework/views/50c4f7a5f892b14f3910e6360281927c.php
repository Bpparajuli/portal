<?php echo csrf_field(); ?>

<div class="row">
    
    <div class="col-md-6 mb-3">
        <label for="first_name">First Name *</label>
        <input type="text" name="first_name" id="first_name" class="form-control" value="<?php echo e(old('first_name', $student->first_name ?? '')); ?>" required>
    </div>
    <div class="col-md-6 mb-3">
        <label for="last_name">Last Name *</label>
        <input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo e(old('last_name', $student->last_name ?? '')); ?>" required>
    </div>
    
    <div class="col-md-6 mb-3">
        <label for="dob">Date of Birth *</label>
        <input type="date" name="dob" id="dob" class="form-control" value="<?php echo e(old('dob', optional($student->dob)->format('Y-m-d') ?? '')); ?>" required>
    </div>
    <div class="col-md-6 mb-3">
        <label for="gender">Gender</label>
        <select name="gender" id="gender" class="form-control">
            <option value="">-- Select --</option>
            <option value="Male" <?php echo e(old('gender', $student->gender ?? '')=='Male'?'selected':''); ?>>Male</option>
            <option value="Female" <?php echo e(old('gender', $student->gender ?? '')=='Female'?'selected':''); ?>>Female</option>
            <option value="Other" <?php echo e(old('gender', $student->gender ?? '')=='Other'?'selected':''); ?>>Other</option>
        </select>
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="email">Email *</label>
        <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $student->email ?? '')); ?>" required>
    </div>
    <div class="col-md-6 mb-3">
        <label for="phone_number">Phone Number *</label>
        <input type="text" name="phone_number" id="phone_number" class="form-control" value="<?php echo e(old('phone_number', $student->phone_number ?? '')); ?>" required>
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="permanent_address">Permanent Address *</label>
        <input type="text" name="permanent_address" id="permanent_address" class="form-control" value="<?php echo e(old('permanent_address', $student->permanent_address ?? '')); ?>" required>
    </div>
    <div class="col-md-6 mb-3">
        <label for="temporary_address">Temporary Address</label>
        <input type="text" name="temporary_address" id="temporary_address" class="form-control" value="<?php echo e(old('temporary_address', $student->temporary_address ?? '')); ?>">
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="nationality">Nationality</label>
        <input type="text" name="nationality" id="nationality" class="form-control" value="<?php echo e(old('nationality', $student->nationality ?? '')); ?>">
    </div>
    <div class="col-md-6 mb-3">
        <label for="marital_status">Marital Status</label>
        <select name="marital_status" id="marital_status" class="form-control">
            <option value="">-- Select --</option>
            <option value="Single" <?php echo e(old('marital_status', $student->marital_status ?? '')=='Single'?'selected':''); ?>>Single</option>
            <option value="Married" <?php echo e(old('marital_status', $student->marital_status ?? '')=='Married'?'selected':''); ?>>Married</option>
        </select>
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="passport_number">Passport Number *</label>
        <input type="text" name="passport_number" id="passport_number" class="form-control" value="<?php echo e(old('passport_number', $student->passport_number ?? '')); ?>">
    </div>
    <div class="col-md-6 mb-3">
        <label for="passport_number">Citizenship Number </label>
        <input type="text" name="citizenship_number" id="citizenship_number" class="form-control" value="<?php echo e(old('citizenship_number', $student->citizenship_number ?? '')); ?>">
    </div>
    <div class="col-md-6 mb-3">
        <label for="passport_expiry">Passport Expiry *</label>
        <input type="date" name="passport_expiry" id="passport_expiry" class="form-control" value="<?php echo e(old('passport_expiry', $student->passport_expiry ?? '')); ?>" required>
    </div>

    
    <div class="col-md-3 mb-3">
        <label for="qualification">Qualification</label>
        <input type="text" name="qualification" id="qualification" class="form-control" value="<?php echo e(old('qualification', $student->qualification ?? '')); ?>">
    </div>
    <div class="col-md-3 mb-3">
        <label for="passed_year">Passed Year</label>
        <input type="text" name="passed_year" id="passed_year" class="form-control" value="<?php echo e(old('passed_year', $student->passed_year ?? '')); ?>">
    </div>
    <div class="col-md-3 mb-3">
        <label for="gap">Gap (years)</label>
        <input type="number" name="gap" id="gap" class="form-control" value="<?php echo e(old('gap', $student->gap ?? '')); ?>">
    </div>
    <div class="col-md-3 mb-3">
        <label for="last_grades">Last Grades</label>
        <input type="text" name="last_grades" id="last_grades" class="form-control" value="<?php echo e(old('last_grades', $student->last_grades ?? '')); ?>">
    </div>
    <div class="col-md-6 mb-3">
        <label for="education_board">Education Board</label>
        <input type="text" name="education_board" id="education_board" class="form-control" value="<?php echo e(old('education_board', $student->education_board ?? '')); ?>">
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="preferred_country">Preferred Country</label>
        <input type="text" name="preferred_country" id="preferred_country" class="form-control" value="<?php echo e(old('preferred_country', $student->preferred_country ?? '')); ?>">
    </div>
    <div class="col-md-6 mb-3">
        <label for="preferred_course">Preferred City</label>
        <input type="text" name="preferred_city" id="preferred_city" class="form-control" value="<?php echo e(old('preferred_course', $student->preferred_course ?? '')); ?>">
    </div>

    
    <h6>Only if Preferred any </h6>

    <div class="row">
        
        <?php
        $selectedUni = old('university_id', $application->university_id ?? '');
        ?>
        <div class="col-md-6 mb-3">
            <?php if (isset($component)) { $__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.select','data' => ['name' => 'university_id','label' => 'University','id' => 'university_select']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'university_id','label' => 'University','id' => 'university_select']); ?>
                <option value="">-- Select University --</option>
                <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($uni->id); ?>" <?php echo e($selectedUni == $uni->id ? 'selected' : ''); ?>>
                    <?php echo e($uni->name); ?> - <?php echo e($uni->city); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36)): ?>
<?php $attributes = $__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36; ?>
<?php unset($__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36)): ?>
<?php $component = $__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36; ?>
<?php unset($__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36); ?>
<?php endif; ?>
        </div>

        
        <?php
        $selectedCourse = old('course_id', $application->course_id ?? '');
        ?>
        <div class="col-md-6 mb-3">
            <?php if (isset($component)) { $__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.select','data' => ['name' => 'course_id','label' => 'Course','id' => 'course_select']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'course_id','label' => 'Course','id' => 'course_select']); ?>
                <option value="">-- Select Course --</option>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($course->id); ?>" <?php echo e($selectedCourse == $course->id ? 'selected' : ''); ?>>
                    <?php echo e($course->title); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36)): ?>
<?php $attributes = $__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36; ?>
<?php unset($__attributesOriginal8cee41e4af1fe2df52d1d5acd06eed36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36)): ?>
<?php $component = $__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36; ?>
<?php unset($__componentOriginal8cee41e4af1fe2df52d1d5acd06eed36); ?>
<?php endif; ?>
        </div>
    </div>


    

    <div class="col-md-12 mb-3">
        <label for="notes">Notes</label>
        <textarea name="notes" id="notes" class="form-control" rows="3"><?php echo e(old('notes', $student->notes ?? '')); ?></textarea>
    </div>

    <div class="col-md-12 mb-3 file-upload-group">
        <label for="students_photo">Student Photo</label>
        <input type="file" name="students_photo" id="students_photo" class="form-control file-input">

        
        <div class="live-preview mt-2"></div>

        
        <?php if(!empty($student->students_photo)): ?>
        <div class="mt-2">
            <img src="<?php echo e(asset('storage/'.$student->students_photo)); ?>" class="rounded" width="120" data-preview="<?php echo e(asset('storage/'.$student->students_photo)); ?>" style="cursor:pointer">
        </div>
        <?php endif; ?>
    </div>

</div>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const uniSelect = document.getElementById('university_select');
        const courseSelect = document.getElementById('course_select');

        if (!uniSelect || !courseSelect) return;

        uniSelect.addEventListener('change', function() {
            const uniId = this.value;
            courseSelect.innerHTML = '<option value="">Loading...</option>';

            if (!uniId) {
                courseSelect.innerHTML = '<option value="">-- Select Course --</option>';
                return;
            }

            fetch(`/agent/applications/get-courses/${uniId}`)
                .then(res => res.ok ? res.json() : [])
                .then(data => {
                    let options = '<option value="">-- Select Course --</option>';
                    if (Array.isArray(data)) {
                        data.forEach(course => {
                            options += `<option value="${course.id}">${course.title}</option>`;
                        });
                    }
                    courseSelect.innerHTML = options;
                })
                .catch(() => {
                    courseSelect.innerHTML = '<option value="">-- Select Course --</option>';
                });
        });
    });

</script>
<?php /**PATH C:\laragon\www\portal\resources\views/agent/students/form.blade.php ENDPATH**/ ?>