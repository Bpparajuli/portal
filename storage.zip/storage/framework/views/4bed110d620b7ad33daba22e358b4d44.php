<?php $__env->startSection('content'); ?>
<div class="create-form-wrapper">
    <h2 class="form-title">➕ Add New Student</h2>

    <form action="<?php echo e(route('admin.students.store')); ?>" method="POST" enctype="multipart/form-data" class="student-form">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.students.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="form-actions d-flex justify-content-between mt-3">
            <button type="submit" class="btn-main">➕ Add Student</button>
            <a href="<?php echo e(route('admin.students.index')); ?>" class="btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\students\create.blade.php ENDPATH**/ ?>