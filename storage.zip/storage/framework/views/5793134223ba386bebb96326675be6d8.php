<?php $__env->startSection('content'); ?>
<div class="p-4">
    <h2>Edit Course</h2>

    <form action="<?php echo e(route('admin.courses.update', $course->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- UNIVERSITY (Readonly like create page) -->
        <div class="row">
            <div class="mb-3">
                <label>University <span class="text-danger">*</span></label>

                <input type="text" class="form-control" value="<?php echo e($course->university->name); ?>" readonly>

                <input type="hidden" name="university_id" value="<?php echo e($course->university_id); ?>">
            </div>
        </div>

        <!-- TITLE & COURSE CODE -->
        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Title <span class="text-danger">*</span></label>
                <input type="text" name="title" value="<?php echo e(old('title', $course->title)); ?>" class="form-control" required>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label>Course Code <span class="text-danger">*</span></label>
                <input type="text" name="course_code" value="<?php echo e(old('course_code', $course->course_code)); ?>" class="form-control" required>
                <?php $__errorArgs = ['course_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- DURATION / FEE / INTAKES -->
        <div class="row">
            <div class="col-md-4 mb-3">
                <label>Duration</label>
                <input type="text" name="duration" value="<?php echo e(old('duration', $course->duration)); ?>" class="form-control">
            </div>

            <div class="col-md-4 mb-3">
                <label>Fee</label>
                <input type="text" name="fee" value="<?php echo e(old('fee', $course->fee)); ?>" class="form-control">
            </div>

            <div class="col-md-4 mb-3">
                <label>Intakes <span class="text-danger">*</span></label>
                <input type="text" name="intakes" value="<?php echo e(old('intakes', $course->intakes)); ?>" class="form-control" required>
                <?php $__errorArgs = ['intakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- COURSE TYPE / MOI -->
        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Course Type <span class="text-danger">*</span></label>
                <select name="course_type" class="form-control" required>
                    <option value="">-- Select Type --</option>
                    <option value="UG" <?php echo e(old('course_type', $course->course_type) == 'UG' ? 'selected' : ''); ?>>Undergraduate</option>
                    <option value="PG" <?php echo e(old('course_type', $course->course_type) == 'PG' ? 'selected' : ''); ?>>Postgraduate</option>
                    <option value="Diploma" <?php echo e(old('course_type', $course->course_type) == 'Diploma' ? 'selected' : ''); ?>>Diploma</option>
                </select>
                <?php $__errorArgs = ['course_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label>MOI Requirement <span class="text-danger">*</span></label>
                <select name="moi_requirement" class="form-control" required>
                    <option value="Yes" <?php echo e(old('moi_requirement', $course->moi_requirement) == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                    <option value="No" <?php echo e(old('moi_requirement', $course->moi_requirement) == 'No' ? 'selected' : ''); ?>>No</option>
                </select>
                <?php $__errorArgs = ['moi_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- COURSE LINK & ACADEMIC REQUIREMENT -->
        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Course Link</label>
                <input type="text" name="course_link" class="form-control" value="<?php echo e(old('course_link', $course->course_link)); ?>">
            </div>

            <div class="col-md-6 mb-3">
                <label>Academic Requirement</label>
                <input type="text" name="academic_requirement" class="form-control" value="<?php echo e(old('academic_requirement', $course->academic_requirement)); ?>">
            </div>
        </div>

        <!-- IELTS / APPLICATION FEE / SCHOLARSHIPS -->
        <div class="row">
            <div class="col-md-4 mb-3">
                <label>IELTS/PTE/Other Languages</label>
                <input type="text" name="ielts_pte_other_languages" value="<?php echo e(old('ielts_pte_other_languages', $course->ielts_pte_other_languages)); ?>" class="form-control">
            </div>

            <div class="col-md-4 mb-3">
                <label>Application Fee</label>
                <input type="text" name="application_fee" value="<?php echo e(old('application_fee', $course->application_fee)); ?>" class="form-control">
            </div>

            <div class="col-md-4 mb-3">
                <label>Scholarships</label>
                <input type="text" name="scholarships" value="<?php echo e(old('scholarships', $course->scholarships)); ?>" class="form-control">
            </div>
        </div>

        <!-- DESCRIPTION -->
        <div class="row">
            <div class="mb-3">
                <label>Description</label>
                <textarea name="description" class="form-control"><?php echo e(old('description', $course->description)); ?></textarea>
            </div>
        </div>

        <!-- BUTTONS -->
        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-primary">Update Course</button>
            <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-danger">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/admin/courses/edit.blade.php ENDPATH**/ ?>