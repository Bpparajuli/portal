<div class="accordion" id="studentAccordion">
    
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingGeneral">
            <button class="accordion-button bg-dark text-light" type="button" data-bs-toggle="collapse" data-bs-target="#collapseGeneral">
                👤 General Info
            </button>
        </h2>
        <div id="collapseGeneral" class="accordion-collapse collapse show" data-bs-parent="#studentAccordion">
            <div class="accordion-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>First Name</label>
                        <input type="text" name="first_name" class="form-control" value="<?php echo e(old('first_name', $student->first_name ?? '')); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Last Name</label>
                        <input type="text" name="last_name" class="form-control" value="<?php echo e(old('last_name', $student->last_name ?? '')); ?>">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label>DOB</label>
                        <input type="date" name="dob" class="form-control" value="<?php echo e(old('dob', isset($student->dob) ? $student->dob->format('Y-m-d') : '')); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>Gender</label>
                        <select name="gender" class="form-select">
                            <?php $__currentLoopData = \App\Models\Student::GENDERS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gender); ?>" <?php echo e(old('gender', $student->gender ?? '') == $gender ? 'selected' : ''); ?>>
                                <?php echo e(ucfirst($gender)); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>Photo</label>
                        <input type="file" name="students_photo" class="form-control">
                        <?php if(!empty($student->students_photo)): ?>
                        <img src="<?php echo e(asset($student->students_photo)); ?>" width="80" class="mt-2 rounded">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $student->email ?? '')); ?>">
                </div>

                <div class="mb-3">
                    <label>Phone</label>
                    <input type="text" name="phone_number" class="form-control" value="<?php echo e(old('phone_number', $student->phone_number ?? '')); ?>">
                </div>

                <div class="mb-3">
                    <label>Permanent Address</label>
                    <textarea name="permanent_address" class="form-control"><?php echo e(old('permanent_address', $student->permanent_address ?? '')); ?></textarea>
                </div>

                <div class="mb-3">
                    <label>Temporary Address</label>
                    <textarea name="temporary_address" class="form-control"><?php echo e(old('temporary_address', $student->temporary_address ?? '')); ?></textarea>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Nationality</label>
                        <input type="text" name="nationality" class="form-control" value="<?php echo e(old('nationality', $student->nationality ?? '')); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Marital Status</label>
                        <input type="text" name="marital_status" class="form-control" value="<?php echo e(old('marital_status', $student->marital_status ?? '')); ?>">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Passport Number</label>
                        <input type="text" name="passport_number" class="form-control" value="<?php echo e(old('passport_number', $student->passport_number ?? '')); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Passport Expiry</label>
                        <input type="date" name="passport_expiry" class="form-control" value="<?php echo e(old('passport_expiry', $student->passport_expiry ?? '')); ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label>Follow-up Date</label>
                    <input type="date" name="follow_up_date" class="form-control" value="<?php echo e(old('follow_up_date', $student->follow_up_date ?? '')); ?>">
                </div>
            </div>
        </div>
    </div>

    
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingAcademic">
            <button class="accordion-button bg-dark text-light collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAcademic">
                🎓 Academic Info
            </button>
        </h2>
        <div id="collapseAcademic" class="accordion-collapse collapse" data-bs-parent="#studentAccordion">
            <div class="accordion-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Qualification</label>
                        <input type="text" name="qualification" class="form-control" value="<?php echo e(old('qualification', $student->qualification ?? '')); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Passed Year</label>
                        <input type="number" name="passed_year" class="form-control" value="<?php echo e(old('passed_year', $student->passed_year ?? '')); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Gap Years</label>
                        <input type="number" name="gap" class="form-control" value="<?php echo e(old('gap', $student->gap ?? '')); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Last Grades</label>
                        <input type="text" name="last_grades" class="form-control" value="<?php echo e(old('last_grades', $student->last_grades ?? '')); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Education Board</label>
                        <input type="text" name="education_board" class="form-control" value="<?php echo e(old('education_board', $student->education_board ?? '')); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Preferred Country</label>
                        <input type="text" name="preferred_country" class="form-control" value="<?php echo e(old('preferred_country', $student->preferred_country ?? '')); ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingApplication">
            <button class="accordion-button bg-dark text-light collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseApplication">
                📑 Application Details
            </button>
        </h2>
        <div id="collapseApplication" class="accordion-collapse collapse" data-bs-parent="#studentAccordion">
            <div class="accordion-body">
                <div class="mb-3">
                    <label>Agent</label>
                    <select name="agent_id" class="form-select">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($agent->id); ?>" <?php echo e(old('agent_id', $student->agent_id ?? '') == $agent->id ? 'selected' : ''); ?>>
                            <?php echo e($agent->business_name ?? $agent->username); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>University</label>
                    <select name="university_id" class="form-select">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($uni->id); ?>" <?php echo e(old('university_id', $student->university_id ?? '') == $uni->id ? 'selected' : ''); ?>>
                            <?php echo e($uni->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Course</label>
                    <select name="course_id" class="form-select">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course->id); ?>" <?php echo e(old('course_id', $student->course_id ?? '') == $course->id ? 'selected' : ''); ?>>
                            <?php echo e($course->title); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Student Status</label>
                    <select name="student_status" class="form-select">
                        <?php $__currentLoopData = ['created','viewed','applied to university','accepted','rejected','applied to another university','forwarded to embassy']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(old('student_status', $student->student_status ?? '') == $status ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($status)); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Notes</label>
                    <textarea name="notes" class="form-control"><?php echo e(old('notes', $student->notes ?? '')); ?></textarea>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\portal\resources\views/admin/students/form.blade.php ENDPATH**/ ?>