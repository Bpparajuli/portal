<?php $__env->startSection('content'); ?>
<div class="p-4">
    <h2>Add New Course</h2>

    <form action="<?php echo e(route('admin.courses.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>University <span class="text-danger">*</span></label>
            <select name="university_id" class="form-control" required>
                <option value="">-- Select University --</option>
                <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($uni->id); ?>" <?php echo e(old('university_id', $selectedUniversity->id ?? '') == $uni->id ? 'selected' : ''); ?>>
                    <?php echo e($uni->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['university_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Course Code <span class="text-danger">*</span></label>
            <input type="text" name="course_code" value="<?php echo e(old('course_code')); ?>" class="form-control" required>
            <?php $__errorArgs = ['course_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Title <span class="text-danger">*</span></label>
            <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" required>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Course Type <span class="text-danger">*</span></label>
            <select name="course_type" class="form-control" required>
                <option value="">-- Select Type --</option>
                <option value="UG" <?php echo e(old('course_type') == 'UG' ? 'selected' : ''); ?>>Undergraduate</option>
                <option value="PG" <?php echo e(old('course_type') == 'PG' ? 'selected' : ''); ?>>Postgraduate</option>
                <option value="Diploma" <?php echo e(old('course_type') == 'Diploma' ? 'selected' : ''); ?>>Diploma</option>
            </select>
            <?php $__errorArgs = ['course_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control"><?php echo e(old('description')); ?></textarea>
        </div>

        <div class="mb-3">
            <label>Duration</label>
            <input type="text" name="duration" value="<?php echo e(old('duration')); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Fee</label>
            <input type="text" name="fee" value="<?php echo e(old('fee')); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Intakes <span class="text-danger">*</span></label>
            <input type="text" name="intakes" value="<?php echo e(old('intakes')); ?>" class="form-control" required>
            <?php $__errorArgs = ['intakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>IELTS/PTE/Other Languages</label>
            <input type="text" name="ielts_pte_other_languages" value="<?php echo e(old('ielts_pte_other_languages')); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>MOI Requirement <span class="text-danger">*</span></label>
            <select name="moi_requirement" class="form-control" required>
                <option value="">-- Select --</option>
                <option value="Yes" <?php echo e(old('moi_requirement') == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                <option value="No" <?php echo e(old('moi_requirement') == 'No' ? 'selected' : ''); ?>>No</option>
            </select>
            <?php $__errorArgs = ['moi_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Application Fee</label>
            <input type="text" name="application_fee" value="<?php echo e(old('application_fee')); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Scholarships</label>
            <input type="text" name="scholarships" value="<?php echo e(old('scholarships')); ?>" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Create Course</button>
        <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\courses\create.blade.php ENDPATH**/ ?>