

<?php $__env->startSection('title', 'Courses'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">All Available Courses</h4>
    </div>

    
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('agent.courses.index')); ?>" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Search (Title / Code)</label>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="e.g. Business Management">
                </div>
                <div class="col-md-3">
                    <label class="form-label">City</label>
                    <input type="text" name="city" value="<?php echo e(request('city')); ?>" class="form-control" placeholder="e.g. London">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Country</label>
                    <input type="text" name="country" value="<?php echo e(request('country')); ?>" class="form-control" placeholder="e.g. UK">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-search"></i> Filter
                    </button>
                    <a href="<?php echo e(route('agent.courses.index')); ?>" class="btn btn-secondary w-100">
                        <i class="fas fa-undo"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class=" table table-striped align-middle">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Course Title</th>
                        <th>University</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>Duration</th>
                        <th>Tuition Fee</th>
                        <th class="text-center" style="width: 180px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($courses->firstItem() + $index); ?></td>
                        <td>
                            <a href="<?php echo e(route('agent.courses.show', $course->id)); ?>">
                                <?php echo e($course->title); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('agent.universities.show', $course->university->id)); ?>" class="text-blue-600 hover:underline">
                                <?php echo e($course->university->name ?? 'N/A'); ?>

                            </a>
                        </td>
                        <td><?php echo e($course->university->city ?? 'N/A'); ?></td>
                        <td><?php echo e($course->university->country ?? 'N/A'); ?></td>
                        <td><?php echo e($course->duration ?? 'N/A'); ?></td>
                        <td> <?php echo e($course->fee); ?></td>
                        <td class="text-center">
                            
                            <a href="<?php echo e(route('agent.courses.show', $course->id)); ?>" class="btn btn-sm btn-primary text-white">
                                <i class="fas fa-eye"> view </i>
                            </a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="25" class="text-center text-muted">No courses found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="card-footer">
            <?php echo e($courses->appends(request()->query())->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/agent/courses/index.blade.php ENDPATH**/ ?>