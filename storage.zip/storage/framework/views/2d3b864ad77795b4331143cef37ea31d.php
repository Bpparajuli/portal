<?php $__env->startSection('content'); ?>
<div class="p-3">
    <div class="row">

        
        <div class="col-lg-4">
            <div class="card sticky-top" style="top:20px;" data-state="#about">
                
                <img class="card-avatar" src="<?php echo e($student->students_photo ? asset('storage/' . $student->students_photo) : asset('images/default-user.png')); ?>" alt="avatar" />

                
                <h1 class="card-fullname"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h1>
                <h2 class="card-jobtitle"><?php echo e($student->agent?->business_name ?? $student->agent?->username ?? 'No Agent Selected'); ?></h2>

                
                <div class="card-main">
                    <div class="card-section is-active" id="about">
                        <div class="card-content text-start">
                            <div class="card-subtitle">PROFILE INFO</div>
                            <p><strong>University:</strong> <?php echo e($student->university?->name ?? '-'); ?></p>
                            <p><strong>Preferred Country:</strong> <?php echo e($student->preferred_country ?? '-'); ?></p>
                            <p><strong>Preferred Course:</strong> <?php echo e($student->preferred_course ?? '-'); ?></p>
                        </div>

                        
                        <?php
                        // Document status calculation
                        $requiredDocumentTypes = ['passport','id','transcript','financial','other'];
                        $uploadedTypes = $student->documents->pluck('document_type')
                        ->map(fn($t) => strtolower(str_replace(' ', '', $t)))
                        ->toArray();
                        $allDocumentsUploaded = count(array_diff($requiredDocumentTypes, $uploadedTypes)) === 0;
                        $completedDocsCount = $student->documents->where('status','completed')->count();

                        $documentStatus = ($allDocumentsUploaded && $completedDocsCount == count($requiredDocumentTypes))
                        ? 'Completed'
                        : (count($uploadedTypes) == 0 ? 'Not Uploaded' : 'Incomplete');
                        ?>
                        <div class="card-social">
                            <a href="<?php echo e(route('admin.students.edit', $student->id)); ?>" class="btn btn-dark btn-sm">✏️ Edit</a>
                            <?php if($allDocumentsUploaded): ?>
                            <a href="<?php echo e(route('admin.applications.create')); ?>?student_id=<?php echo e($student->id); ?>" class="btn btn-sm btn-success">
                                <i class="fa-solid fa-paper-plane me-1"></i> Apply Now
                            </a>
                            <?php else: ?>
                            <a href="<?php echo e(route('admin.documents.index', $student->id)); ?>" class="btn btn-sm btn-secondary ">
                                <i class="fa-solid fa-folder-open me-1"></i> View Docs
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-lg-8">
            
            <ul class="nav nav-tabs custom-tabs mb-3" role="tablist">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#general">👤 Information</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#documents">📂 Documents</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#application">📑 Application</button></li>
            </ul>

            <div class="tab-content ">
                
                <div class="tab-pane fade show active" id="general">
                    <div class="bg-light rounded m-2 p-2 shadow-sm ">
                        <h5 class="mb-3">General Info</h5>
                        <div class="row">
                            <div class="col-md-6 my-2"><strong>Name:</strong> <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></div>
                            <div class="col-md-6 my-2"><strong>Email:</strong> <?php echo e($student->email); ?></div>
                            <div class="col-md-6 my-2"><strong>Phone:</strong> <?php echo e($student->phone_number); ?></div>
                            <div class="col-md-6 my-2"><strong>DOB:</strong> <?php echo e($student->dob ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Gender:</strong> <?php echo e($student->gender ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Nationality:</strong> <?php echo e($student->nationality ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Passport No:</strong> <?php echo e($student->passport_number ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Expiry Date:</strong> <?php echo e($student->passport_expiry ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Marital Status:</strong> <?php echo e($student->marital_status ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Permanent Address:</strong> <?php echo e($student->permanent_address ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Temporary Address:</strong> <?php echo e($student->temporary_address ?? '-'); ?></div>
                        </div>
                    </div>
                    <div class="bg-light rounded m-2 p-2 shadow-sm" id="general">
                        <h5 class="mb-3">Academic Info</h5>
                        <div class="row">
                            <div class="col-md-6 my-2"><strong>Qualification:</strong> <?php echo e($student->qualification ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Passed Year:</strong> <?php echo e($student->passed_year ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Gap Years:</strong> <?php echo e($student->gap ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Last Grades:</strong> <?php echo e($student->last_grades ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Education Board:</strong> <?php echo e($student->education_board ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Preferred Country:</strong> <?php echo e($student->preferred_country ?? '-'); ?></div>
                            <div class="col-md-6 my-2"><strong>Preferred Course:</strong> <?php echo e($student->preferred_course ?? '-'); ?></div>
                        </div>
                    </div>
                </div>
                
                <div class="tab-pane fade" id="application">
                    <h5 class="mb-3">📄 Applications List with Details</h5>
                    <?php if($student->applications && $student->applications->isNotEmpty()): ?>
                    <?php $__currentLoopData = $student->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow-sm bg-light mb-4 border-0 rounded-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h6 class="mb-3 text-primary">
                                    Application Number: <?php echo e($application->application_number ?? 'N/A'); ?>

                                </h6>
                                <h6 class="mb-3 text-primary">
                                    Application Submitted On: <?php echo e($application->created_at->format('Y-m-d')); ?>

                                </h6>
                            </div>
                            
                            <div class=" row">
                                <div class="col-md-6 my-2"><strong>Country:</strong> <?php echo e($application->university->country ?? 'N/A'); ?></div>
                                <div class="col-md-6 my-2"><strong>City:</strong> <?php echo e($application->university->city ?? 'N/A'); ?></div>
                                <div class="col-md-6 my-2"><strong>University:</strong> <?php echo e($application->university->name ?? 'N/A'); ?></div>
                                <div class="col-md-6 my-2"><strong>Course:</strong> <?php echo e($application->course->title ?? 'N/A'); ?></div>
                                <div class="col-md-6 my-2"><strong>Duration:</strong> <?php echo e($application->course->duration ?? 'N/A'); ?></div>
                                <div class="col-md-6 my-2"><strong>Fee:</strong> <?php echo e($application->course->fee ?? 'N/A'); ?></div>
                            </div>
                            <div class="d-flex justify-content-between">
                                
                                <div class="p-3 bg-white border rounded-3">
                                    <h6 class="fw-bold">📌 Application Status</h6>
                                    <div class="m-1 p-3 rounded-2 badge <?php echo e($application->status_class); ?>">
                                        <?php echo e($application->application_status); ?>

                                    </div>
                                </div>
                                
                                <div class="p-3 bg-white border rounded-3">
                                    <h6 class="fw-bold">📑 Statement of Purpose</h6>
                                    <div class="m-1">
                                        <?php if($application->sop_file): ?>
                                        <a href="#" data-preview="<?php echo e(Storage::url($application->sop_file)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                            👁️ SOP
                                        </a>
                                        <?php else: ?>
                                        <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="p-3 bg-white border rounded-3">
                                    <h6 class="fw-bold">Actions</h6>
                                    <div class="m-1 d-flex gap-1">
                                        <div class="">
                                            <a href="<?php echo e(route('admin.applications.edit', $application->id)); ?>" class="btn p-2 border border-success">
                                                📝 Edit
                                            </a>
                                        </div>
                                        <div class="">
                                            <a href="<?php echo e(route('admin.applications.show', $application->id)); ?>" class="btn p-2 border border-secondary">
                                                👁️ View
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4 p-3 bg-white border rounded-3">
                                <h5 class="fw-bold mb-3">💬 Messages</h5>
                                <div class="border rounded p-3 mb-3" style="max-height: 400px; overflow-y: auto;">
                                    <?php $__empty_1 = true; $__currentLoopData = $application->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="d-flex mb-2 <?php echo e($m->type === 'agent' ? 'justify-content-start' : 'justify-content-end'); ?>">
                                        <div class="p-2 rounded" style="max-width:70%; background-color: <?php echo e($m->type === 'agent' ? '#f1f1f1' : '#1a0262'); ?>;
                                       color: <?php echo e($m->type === 'agent' ? '#000' : '#fff'); ?>;">
                                            <p class="mb-1 fw-semibold"><?php echo e($m->message); ?></p>
                                            <small><b><?php echo e($m->user->name ?? 'Unknown'); ?></b> • <?php echo e($m->created_at->format('d M Y, H:i')); ?></small>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-muted">No messages yet.</p>
                                    <?php endif; ?>
                                </div>
                                <form method="POST" action="<?php echo e(route('admin.applications.addMessage', $application)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex">
                                        <textarea name="message" class="form-control me-2" rows="2" placeholder="Add a message..." required></textarea>
                                        <button type="submit" class="btn btn-primary btn-sm">Send</button>
                                    </div>
                                </form>
                            </div>
                            
                            <div class="mt-3">
                                <a href="<?php echo e(route('admin.applications.edit', $application->id)); ?>" class="btn btn-primary btn-sm">
                                    ✏️ Edit Application
                                </a>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <p class="text-muted">Please Upload all necessary Documents and Add Application for this Student.</p>
                    <?php endif; ?>
                </div>

                
                <div class="tab-pane fade" id="documents">
                    
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="mb-0">📂 Documents</h6>
                        <?php if($allDocumentsUploaded): ?>
                        <a href="<?php echo e(route('admin.applications.create')); ?>?student_id=<?php echo e($student->id); ?>" class="btn btn-sm btn-success">
                            <i class="fa-solid fa-paper-plane me-1"></i> Apply Now
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('admin.documents.index', $student->id)); ?>" class="btn btn-sm btn-secondary">
                            <i class="fa-solid fa-folder-open me-1"></i> View All Docs
                        </a>
                        <?php endif; ?>
                    </div>

                    <?php if($student->documents->isEmpty()): ?>
                    <p class="text-muted small mb-0">No documents uploaded yet.</p>
                    <?php else: ?>
                    <div class="row g-2">
                        <?php $__currentLoopData = $student->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $extension = pathinfo($doc->file_name, PATHINFO_EXTENSION);
                        $isImage = in_array(strtolower($extension), ['jpg','jpeg','png','gif','webp']);
                        $filePath = asset('storage/' . $doc->file_path);
                        ?>
                        <div class="col-6 col-md-3">
                            <div class="card document-card shadow-sm p-1 text-center" style="font-size:0.8rem;">
                                
                                <a href="#" data-preview="<?php echo e($filePath); ?>">
                                    <?php if($isImage): ?>
                                    <img src="<?php echo e($filePath); ?>" class="img-fluid rounded" alt="Doc" style="height:80px; object-fit:cover;">
                                    <?php else: ?>
                                    <div class="doc-placeholder py-3">
                                        <i class="fa fa-file fa-2x text-secondary"></i>
                                        <div><?php echo e(strtoupper($extension)); ?></div>
                                    </div>
                                    <?php endif; ?>
                                </a>

                                
                                <div class="mt-1">
                                    <div class="text-truncate"><?php echo e($doc->custom_name ?? ucwords(str_replace('_',' ', $doc->document_type))); ?></div>
                                    <small class="text-muted"><?php echo e($doc->created_at->format('Y-m-d')); ?></small>
                                </div>

                                <div class="d-flex px-2 justify-content-between gap-1 mt-1">
                                    <a href="<?php echo e(route('admin.documents.download', ['student'=>$student->id, 'document'=>$doc->id])); ?>" class="btn btn-sm btn-success p-1">
                                        <i class="fa fa-download"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.documents.destroy', [$student->id, $doc->id])); ?>" onsubmit="return confirm('Delete this document?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-outline-danger p-1"><i class="fa fa-trash"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>

            </div>
            
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\students\show.blade.php ENDPATH**/ ?>