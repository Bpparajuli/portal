

<?php $__env->startSection('agent-content'); ?>
<div class="container py-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0">🎓 Applications for <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h4>
        <a href="<?php echo e(route('agent.students.index')); ?>" class="btn btn-outline-secondary btn-sm">
            ← Back to Students
        </a>
    </div>

    <?php if($student->applications->count()): ?>
    <div class="d-flex flex-column gap-4">
        <?php $__currentLoopData = $student->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card shadow-sm border-0 rounded-3 p-3">
            <div class="row align-items-start g-3">
                
                <div class="col-md-3">
                    <h6 class="fw-bold text-primary mb-1"><?php echo e($application->university->name ?? 'N/A'); ?></h6>
                    <p class="mb-1 small"><?php echo e($application->course->title ?? 'N/A'); ?></p>
                    <span class="badge bg-info text-dark"><?php echo e(ucfirst($application->application_status ?? 'N/A')); ?></span>
                </div>

                
                <div class="col-md-4">
                    <label class="fw-semibold mb-2">📑 SOP (Statement of Purpose)</label>

                    <?php if($application->sop_file): ?>
                    <div class="d-flex align-items-center gap-3 border rounded p-2 bg-light">
                        <a href="#" data-preview="<?php echo e(asset('storage/' . $application->sop_file)); ?>" target="_blank" class="d-flex gap-3 align-items-center w-100">
                            <div style="width:90px; height:110px; overflow:hidden; border-radius:6px; border:1px solid #ddd; display:flex; align-items:center; justify-content:center;">
                                <iframe src="<?php echo e(asset('storage/' . $application->sop_file)); ?>" style="width:100%; height:100%; border:none;" loading="lazy">
                                    <p class="small text-muted">Preview not available</p>
                                </iframe>
                            </div>
                            <?php
                            $ext = strtoupper(pathinfo($application->sop_file, PATHINFO_EXTENSION));
                            ?>
                            <div class="flex-grow-1">
                                <p class="mb-1"><strong><?php echo e(basename($application->sop_file)); ?></strong></p>
                                <p class="small text-muted mb-2"><?php echo e($ext); ?></p>
                            </div>
                        </a>
                    </div>
                    <?php else: ?>
                    <span class="text-danger small">⚠️ SOP not uploaded</span>
                    <?php endif; ?>
                </div>

                
                <div class="col-md-2">
                    <small class="text-muted d-block">Submitted On</small>
                    <span><?php echo e($application->created_at->format('d M, Y')); ?></span>
                </div>

                
                <div class="col-md-3 d-flex flex-column align-items-end gap-2">
                    <a href="<?php echo e(route('agent.applications.show', $application->id)); ?>" class="btn btn-sm btn-primary w-100">
                        <i class="fa-solid fa-eye me-1"></i> View Details
                    </a>
                    <?php if(!$application->sop_file): ?>
                    <span class="text-danger small">⚠️ SOP Missing</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <div class="alert alert-info">No applications found for this student.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\agent\applications\for_student.blade.php ENDPATH**/ ?>