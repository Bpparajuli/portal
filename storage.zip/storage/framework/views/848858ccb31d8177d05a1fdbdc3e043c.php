

<?php $__env->startSection('content'); ?>
<div class="uni-page">

    
    <?php echo $__env->make('partials.uni_filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="uni-cards-grid mt-3">
        <?php $__empty_1 = true; $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="uni-card">
            <div class="uni-card-header">
                <?php if($uni->university_logo): ?>
                <a href="<?php echo e(route('guest.universities.show', $uni->id)); ?>">
                    <img src="<?php echo e(asset('storage/uni_logo/'.$uni->university_logo)); ?>" class="uni-logo" alt="<?php echo e($uni->name); ?>">
                </a>
                <?php endif; ?>
            </div>
            <div class="uni-card-body">
                <h3 class="uni-card-title">
                    <a href="<?php echo e(route('guest.universities.show', $uni->id)); ?>">
                        <?php echo e($uni->name); ?>

                    </a>
                </h3>
                <p class="uni-card-subtitle">
                    <a href="<?php echo e(route('guest.universities.show', $uni->id)); ?>">
                        <?php echo e($uni->short_name ?? 'N/A'); ?> (<?php echo e($uni->id ?? 'N/A'); ?>)
                    </a>
                </p>
                <p class="uni-card-location"><?php echo e($uni->city ?? 'N/A'); ?>, <?php echo e($uni->country); ?></p>
                <p>
                    <?php if($uni->website): ?>
                    <a href="<?php echo e($uni->website); ?>" target="_blank" class="uni-web-link" rel="noopener"><?php echo e($uni->website); ?></a>
                    <?php endif; ?>
                </p>
                
            </div>

            <?php if($uni->courses->count()): ?>
            <div class="uni-card-footer">
                <button class="uni-btn-toggle btn-primary" onclick="openCourseModal(<?php echo e($uni->id); ?>)">
                    View Courses (<?php echo e($uni->courses->count()); ?>)
                </button>
            </div>
            <?php endif; ?>
        </div>

        
        <div id="courseModal<?php echo e($uni->id); ?>" class="uni-modal">
            <div class="uni-modal-content">
                <span class="uni-modal-close" onclick="closeCourseModal(<?php echo e($uni->id); ?>)">&times;</span>
                <h3>Courses of <?php echo e($uni->name); ?></h3>
                <table class="uni-inner-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Duration</th>
                            <th>Fee</th>
                            <th>Intakes</th>
                            <th>MOI</th>
                            <th>Scholarships </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $uni->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($course->course_code); ?></td>
                            <td><?php echo e($course->title); ?></td>
                            <td><?php echo e($course->description ?? 'N/A'); ?></td>
                            <td><?php echo e($course->duration ?? 'N/A'); ?></td>
                            <td>$<?php echo e($course->fee); ?></td>
                            <td><?php echo e($course->intakes ?? 'N/A'); ?></td>
                            <td><?php echo e($course->moi_requirement ?? 'N/A'); ?></td>
                            <td><?php echo e($course->scholarships ?? 'N/A'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="uni-no-data">No universities found.</p>
        <?php endif; ?>
    </div>

    <div class="pagination-wrap mt-4">
        <?php echo e($universities->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function openCourseModal(id) {
        document.getElementById('courseModal' + id).style.display = 'block';
    }

    function closeCourseModal(id) {
        document.getElementById('courseModal' + id).style.display = 'none';
    }

    // Close modal on outside click
    window.onclick = function(event) {
        document.querySelectorAll('.uni-modal').forEach(modal => {
            if (event.target == modal) modal.style.display = "none";
        });
    }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\guest\universities\index.blade.php ENDPATH**/ ?>