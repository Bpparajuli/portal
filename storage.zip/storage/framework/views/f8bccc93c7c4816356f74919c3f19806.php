
<?php $__env->startSection('admin-content'); ?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold"><i class="fa fa-file-alt text-success me-2"></i>Applications of <?php echo e($agent->business_name); ?></h3>
        <form method="GET" class="d-flex gap-2">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Search by uni,student...">
            <button class="btn btn-success"><i class="fa fa-search me-1"></i>Search</button>
        </form>
    </div>
    <?php if($applications->count()): ?>
    <div class="table-wrapper">
        <table class="table table-hover table-striped align-middle shadow-sm rounded text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>University</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>Submitted On</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('admin.applications.show', $app->id)); ?>" class="text-decoration-none">
                            <?php echo e($app->id); ?>

                        </a>
                    </td>
                    <td><?php echo e($app->student->first_name ?? 'N/A'); ?> <?php echo e($app->student->last_name ?? ''); ?></td>
                    <td><?php echo e($app->course->university->name ?? 'N/A'); ?></td>
                    <td><?php echo e($app->course->name ?? 'N/A'); ?></td>
                    <td>
                        <?php
                        $statusClass = match($app->application_status) {
                        'Accepted by the University' => 'success',
                        'Rejected by the University' => 'danger',
                        'Need to give the test' => 'warning',
                        'Application started' => 'secondary',
                        default => 'primary',
                        };
                        ?>
                        <a href="<?php echo e(route('admin.applications.show', $app->id)); ?>" class="badge bg-<?php echo e($statusClass); ?> text-decoration-none">
                            <?php echo e($app->application_status); ?>

                        </a>
                    </td>
                    <td><?php echo e($app->created_at->format('d M Y')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-center mt-4">
        <?php echo e($applications->links('pagination::bootstrap-5')); ?>

    </div>
    <?php else: ?>
    <div class="alert alert-info text-center">No applications found for this agent.</div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\users\applications.blade.php ENDPATH**/ ?>