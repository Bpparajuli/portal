

<?php $__env->startSection('content'); ?>
<div class="mt-4">
    <h4>Upload document for: <strong><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></strong></h4>

    <form action="<?php echo e(route('admin.documents.store', $student->id)); ?>" method="POST" enctype="multipart/form-data" class="mt-3">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">File</label>
            <input type="file" name="file" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Document type (optional)</label>
            <input type="text" name="document_type" class="form-control" placeholder="e.g. passport, transcript">
        </div>

        <button class="btn btn-success">Upload</button>
        <a href="<?php echo e(route('admin.documents.index', $student->id)); ?>" class="btn btn-outline-secondary">Back</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\documents\create.blade.php ENDPATH**/ ?>