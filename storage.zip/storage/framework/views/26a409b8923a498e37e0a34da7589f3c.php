<?php $__env->startSection('content'); ?>
<div class="student-form-wrapper">
    <div class="header-bar d-flex justify-content-between align-items-center mb-3">
        <h2 class="form-title">✏️ Edit Student</h2>
        <a href="<?php echo e(route('admin.students.show', $student->id)); ?>" class="btn btn-outline-secondary">👤 Back to Profile</a>
    </div>

    <form action="<?php echo e(route('admin.students.update', $student->id)); ?>" method="POST" enctype="multipart/form-data" class="student-form">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('admin.students.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
    <div class="form-actions d-flex justify-content-between m-2">
        <button type="submit" class="btn btn-success">💾 Save Changes</button>
        <a href="<?php echo e(route('admin.documents.create', $student->id)); ?>" class="btn btn-warning">📄 Upload Document</a>
        <form action="<?php echo e(route('admin.students.destroy', $student->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');" style="display: inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">🗑️ Delete Student</button>
        </form>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\students\edit.blade.php ENDPATH**/ ?>