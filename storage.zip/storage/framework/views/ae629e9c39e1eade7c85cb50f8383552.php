

<?php $__env->startSection('admin-content'); ?>
<div class="container p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>📑 All Applications</h3>
        <form method="GET" action="<?php echo e(route('admin.applications.index')); ?>">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by student, course, or university" value="<?php echo e(request('search')); ?>">
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </form>
    </div>
    <div class="table-responsive">
        <table class=" table table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>University</th>
                    <th>Course</th>
                    <th>Agent</th>
                    <th>Status</th>
                    <th>SOP</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($app->id); ?></td>
                    <td>
                        <?php echo e($app->student ? $app->student->first_name . ' ' . $app->student->last_name : 'N/A'); ?>

                    </td>
                    <td><?php echo e($app->university->name ?? 'N/A'); ?></td>
                    <td><?php echo e($app->course->title ?? 'N/A'); ?></td>
                    <td>
                        <?php echo e($app->agent ? $app->agent->business_name ?? $app->agent->username : 'Admin Added'); ?>

                    </td>
                    <td>
                        <span class="badge <?php echo e($app->status_class ?? 'bg-light text-muted'); ?>">
                            <?php echo e($app->application_status); ?>

                        </span>
                    </td>
                    <td>
                        <?php if($app->sop_file): ?>
                        <a href="#" data-preview="<?php echo e(Storage::url($app->sop_file)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                            👁️ SOP
                        </a>
                        <?php else: ?>
                        <span class="text-muted">Not uploaded</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="<?php echo e(route('admin.applications.show', $app->id)); ?>" class="p-2 btn btn-sm btn-secondary">
                                View
                            </a>
                            <a href="<?php echo e(route('admin.applications.edit', $app->id)); ?>" class="p-2 btn btn-sm btn-dark">
                                edit
                            </a>
                        </div>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center text-muted">No applications found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\applications\index.blade.php ENDPATH**/ ?>