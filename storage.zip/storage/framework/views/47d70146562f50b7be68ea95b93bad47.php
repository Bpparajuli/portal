<?php $__env->startSection('content'); ?>
<?php if(auth()->check() && auth()->user()->is_admin): ?>
<div>
    <div class="row justify-content-center">
        <div class="col-md-6 p-3 border border-primary rounded bg-white d-flex flex-column align-items-center">
            <h3 class="d-inline-block mx-auto p-3 text-white text-center fw-bold bg-primary mb-3">Edit Existing User</h3>
            <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data" class="w-100">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <!-- Add this line -->
                <?php echo $__env->make('partials.form', ['edit' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
            </form>
        </div>
    </div>
    <div class="row justify-content-center mt-3">
        <div class="col-md-6 d-inline-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn bg-gray-400 btn-secondary">Back to User List</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>