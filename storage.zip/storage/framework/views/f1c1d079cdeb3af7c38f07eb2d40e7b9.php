


<?php $__env->startSection('agent-content'); ?>

<div class="full-width">
    <div>
        <h2>Hi <?php echo e(auth()->user()->name); ?>, Welcome Back!</h2>
        <p class="sub-text">Here's a quick overview of your students & applications.</p>
    </div>
    <div class="actions">
        <a href="<?php echo e(route('agent.students.create')); ?>" class="btn btn-primary"><i class="fa fa-user"></i> Add Student</a>
        <a href="<?php echo e(route('agent.applications.create')); ?>" class="btn btn-secondary"><i class="fa fa-vcard"></i> New Application</a>
    </div>

</div>
<div class="uni-filter p-4">
    <?php echo $__env->make('partials.uni_filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<div class="container">

    <div class="content">

        
        <div class="left-column">

            
            <div class="card">
                <div class="stats-row">
                    <a href="<?php echo e(route('agent.students.index')); ?>" class="stat-link">
                        <div class="stat-card">
                            <div class="stat-left">
                                <h6>Total Students</h6>
                                <h2><?php echo e($totalStudents ?? 0); ?></h2>
                            </div>
                            <div class="icon text-primary"><i class="fa fa-users"></i></div>
                        </div>
                    </a>
                    <a href="<?php echo e(route('agent.applications.index')); ?>" class="stat-link">
                        <div class="stat-card">
                            <div class="stat-left">
                                <h6>Applications Submitted</h6>
                                <h2><?php echo e($totalApplications ?? 0); ?></h2>
                            </div>
                            <div class="icon text-secondary"><i class="fa fa-vcard"></i></div>
                        </div>
                    </a>
                    <a href="<?php echo e(route('agent.universities.index')); ?>" class="stat-link">
                        <div class="stat-card">
                            <div class="stat-left">
                                <h6>Available Universities</h6>
                                <h2><?php echo e($totalUniversities ?? 0); ?></h2>
                            </div>
                            <div class="icon text-primary"><i class="fa fa-university"></i></div>
                        </div>
                    </a>
                </div>
            </div>

            
            <div class="card chart-card">
                <h6>Monthly Applications (Last 12 months)</h6>
                <canvas id="monthlyChart" class="canvas-medium"></canvas>
            </div>

            
            <div class="card chart-card">
                <h6>Applications by Country</h6>
                <canvas id="countryChart" class="canvas-medium"></canvas>
            </div>

            
            <div class="card pipeline-card">
                <h6>Student Application Pipeline</h6>
                <img src="<?php echo e(asset('images/pipeline.png')); ?>" alt="Application Pipeline">
            </div>
        </div>

        
        <div class="right-content">
            
            <div class="card progress-card">
                <h6>Application Progress</h6>
                <canvas id="progressChart" class="canvas-small"></canvas>
                <div class="progress-stats grid-two-columns">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="stat" style="background-color: <?php echo e($statusColors[$i]); ?>; color: #fff; font-weight: bold;">
                        <?php echo e($s); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
            <div class="card">
                <h6>Visa Approved Conversion</h6>
                <canvas id="conversionChart" class="canvas-small"></canvas>
                <p class="sub-text-bold"><?php echo e($visaConversionPercent ?? 0); ?>% Visa Approved</p>
            </div>
            
            <div class="card events-card">
                <h6 class="gradient section-title">Upcoming Trainings & Counselling</h6>
                <div class="events-grid">
                    <div>
                        <h6>Trainings</h6>
                        <ul>
                            <li>Embassy Training – Sept 15</li>
                            <li>Agent Portal Training – Sept 20</li>
                            <li>University Portal Training – Sept 25</li>
                            <li>University Portal Training – Sept 25</li>
                            <li>University Portal Training – Sept 25</li>
                        </ul>
                    </div>
                    <div>
                        <h6>Counselling</h6>
                        <ul>
                            <li>Gisma Counselling – Sept 15</li>
                            <li>PFH Counselling – Sept 20</li>
                            <li>SRH Counselling – Sept 25</li>
                            <li>University Portal Training – Sept 25</li>
                            <li>University Portal Training – Sept 25</li>

                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>

    
    <div class="card widgets-card">
        <div class="widgets-row">
            <div class="widget">
                <div>
                    <div class="widget-title">Today's Activities</div>
                    <div class="widget-value"><?php echo e($todayActivitiesCount ?? 0); ?></div>
                </div>
            </div>

            <div class="widget">
                <div class="widget-title">Applications this month</div>
                <div class="d-flex justify-content-between">
                    <div class="widget-value"><?php echo e($recentApplications->count() ?? 0); ?></div>
                    <div class="widget-link">
                        <a href="<?php echo e(route('agent.applications.index')); ?>">View</a>
                    </div>
                </div>

            </div>

            <div class="widget">
                <div>
                    <div class="widget-title">Quick Actions</div>
                    <div class="quick-actions">
                        <a href="<?php echo e(route('agent.applications.index')); ?>" class="btn btn-primary mini-btn">Check Applications</a>
                        <a href="<?php echo e(route('agent.students.index')); ?>" class="btn btn-secondary mini-btn">Student Status</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="activities-row">
        <div class="activity-card card">
            <h6>Students Activities</h6>
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $studentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <div>
                        <?php if($act->notifiable_id): ?>
                        <a href="<?php echo e(route('agent.students.show', $act->notifiable_id)); ?>"><?php echo e($act->description); ?></a>
                        <?php else: ?>
                        <?php echo e($act->description); ?>

                        <?php endif; ?>
                        <div class="time-text"><?php echo e($act->created_at->diffForHumans()); ?></div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>No students activities</li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="activity-card card">
            <h6>Documents</h6>
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $documentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <div>
                        <?php if($act->notifiable_id): ?>
                        <a href="<?php echo e(route('agent.documents.index', $act->notifiable_id)); ?>">
                            <?php echo e($act->description); ?>

                        </a>
                        <?php else: ?>
                        <?php echo e($act->description); ?>

                        <?php endif; ?>
                        <div class="time-text"><?php echo e($act->created_at->diffForHumans()); ?></div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>No document activities</li>
                <?php endif; ?>
            </ul>
        </div>



        <div class="activity-card card">
            <h6>Applications</h6>
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $applicationActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <div>
                        <?php if($act->notifiable_id): ?>
                        <a href="<?php echo e(route('agent.applications.show', $act->notifiable_id)); ?>"><?php echo e($act->description); ?></a>
                        <?php else: ?>
                        <?php echo e($act->description); ?>

                        <?php endif; ?>
                        <div class="time-text"><?php echo e($act->created_at->diffForHumans()); ?></div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>No applications yet</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<?php
// Status chart data
$statusCounts = [];
foreach ($statuses as $s) { $statusCounts[] = $applicationStatusCounts->get($s, 0); }
$statusColors = [
'#3b82f6', // Application started - Blue
'#60a5fa', // Viewed by Admin - Light Blue
'#818cf8', // Applied to University - Indigo
'#facc15', // Need to give the test - Yellow
'#22c55e', // Accepted by University - Green
'#ef4444', // Rejected by University - Red
'#8b5cf6', // Applied to another university - Purple
'#f97316', // Forwarded to embassy - Orange
'#0ea5e9', // On waiting list at embassy - Sky Blue
'#16a34a', // Visa Approved - Dark Green
'#b91c1c', // Visa Rejected - Dark Red
'#6b7280' // Lost - Gray
];
?>

<script>
    document.addEventListener('DOMContentLoaded', function() {

        // Visa Conversion
        new Chart(document.getElementById('conversionChart'), {
            type: 'doughnut'
            , data: {
                labels: ['Visa Approved', 'Remaining']
                , datasets: [{
                    data: [<?php echo json_encode($visaApproved, 15, 512) ?>, Math.max(<?php echo json_encode($totalApplications, 15, 512) ?> - <?php echo json_encode($visaApproved, 15, 512) ?>, 0)]
                    , backgroundColor: ['#22c55e', '#e5e7eb']
                }]
            }
            , options: {
                cutout: '70%'
                , plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Application Progress
        new Chart(document.getElementById('progressChart'), {
            type: 'doughnut'
            , data: {
                labels: <?php echo json_encode($statuses, 15, 512) ?>
                , datasets: [{
                    data: <?php echo json_encode($statusCounts, 15, 512) ?>
                    , backgroundColor: <?php echo json_encode($statusColors, 15, 512) ?>
                    , borderWidth: 1
                    , borderColor: '#fff'
                    , hoverOffset: 8
                }]
            }
            , options: {
                cutout: '0%'
                , responsive: true
                , plugins: {
                    legend: {
                        display: false
                    }
                    , tooltip: {
                        callbacks: {
                            label: ctx => {
                                const total = <?php echo json_encode($statusCounts, 15, 512) ?>.reduce((a, b) => a + b, 0);
                                const pct = total ? Math.round(ctx.raw / total * 100) : 0;
                                return `${ctx.label}: ${ctx.raw} (${pct}%)`;
                            }
                        }
                    }
                }
            }
        });

        // Monthly Applications Line Chart
        new Chart(document.getElementById('monthlyChart'), {
            type: 'line'
            , data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
                , datasets: [{
                    label: 'Applications'
                    , data: <?php echo json_encode($monthlyArr, 15, 512) ?>
                    , borderColor: '#4f46e5'
                    , backgroundColor: 'rgba(79,70,229,0.12)'
                    , fill: true
                    , tension: 0.32
                    , pointRadius: 3
                }]
            }
            , options: {
                responsive: true
                , scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Country Bar Chart
        new Chart(document.getElementById('countryChart'), {
            type: 'bar'
            , data: {
                labels: <?php echo json_encode($countryLabels, 15, 512) ?>
                , datasets: [{
                    label: 'Applications'
                    , data: <?php echo json_encode($countryCounts, 15, 512) ?>
                    , backgroundColor: '#3b82f6'
                }]
            }
            , options: {
                responsive: true
                , scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/agent/dashboard.blade.php ENDPATH**/ ?>