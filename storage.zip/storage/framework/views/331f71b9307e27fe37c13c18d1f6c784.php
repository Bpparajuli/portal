

<?php $__env->startSection('content'); ?>
<div class=" mt-4">
    <div class="d-flex justify-content-between px-5 mb-3">
        <div class="detail">
            <h2><?php echo e($university->name); ?> (<?php echo e($university->short_name ?? ''); ?>)</h2>
            <p><strong>Country:</strong> <?php echo e($university->country); ?></p>
            <p><strong>City:</strong> <?php echo e($university->city); ?></p>
            <p><strong>Email:</strong> <?php echo e($university->contact_email); ?></p>
            <p><strong>Website:</strong> <a href="<?php echo e($university->website); ?>" target="_blank"><?php echo e($university->website); ?></a></p>
            <p><?php echo e($university->description); ?></p>
        </div>
        <div class="business-logo">
            <?php if($university->university_logo): ?>
            <img src="<?php echo e(asset('images/uni_logo/' . $university->university_logo)); ?>" alt="Logo" class="uni-logo">
            <?php endif; ?>
        </div>
    </div>
</div>
<hr>

<h3>Courses</h3>


<?php if($university->courses->count()): ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Course Code</th>
            <th>Title</th>
            <th>Duration</th>
            <th>Fee</th>
            <th>Intakes</th>
            <th>MOI Requirement</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $university->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($course->course_code); ?></td>
            <td><?php echo e($course->title); ?></td>
            <td><?php echo e($course->duration); ?></td>
            <td><?php echo e($course->fee); ?></td>
            <td><?php echo e($course->intakes); ?></td>
            <td><?php echo e($course->moi_requirement); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<p>No courses found for this university.</p>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\agent\universities\show.blade.php ENDPATH**/ ?>