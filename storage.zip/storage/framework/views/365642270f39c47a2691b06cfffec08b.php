<?php $__env->startSection('agent-content'); ?>
<div class="create-form-wrapper">
    <h2 class="form-title">➕ Add New Student</h2>

    <form action="<?php echo e(route('agent.students.store')); ?>" method="POST" enctype="multipart/form-data" class="card p-4 shadow-sm mt-3">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('agent.students.form', ['student' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="form-actions mt-3">
            <button type="submit" class="btn btn-success">💾 Save Student</button>
            <a href="<?php echo e(route('agent.students.index')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\agent\students\create.blade.php ENDPATH**/ ?>