<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<?php $__env->startSection('content'); ?>
<div class="student-page container">

    
    <div class="filter-card mb-4 p-2 rounded shadow-sm">
        <form method="GET" action="<?php echo e(route('agent.students.index')); ?>" class="filter-form">
            <div class="row g-3 align-items-end">
                
                <div class="col-md-2">
                    <label for="search">Search by Name</label>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control">
                </div>

                
                <div class="col-md-2">
                    <label for="country">Country</label>
                    <select name="country" class="form-select">
                        <option value="">All</option>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country); ?>" <?php echo e(request('country') == $country ? 'selected' : ''); ?>>
                            <?php echo e($country); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="university">University</label>
                    <select name="university" id="university" class="form-select">
                        <option value="">All</option>
                        <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($university->id); ?>" <?php echo e(request('university') == $university->id ? 'selected' : ''); ?>>
                            <?php echo e($university->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="application_status">Application Status</label>
                    <select name="application_status" class="form-select">
                        <option value="">All</option>
                        <?php $__currentLoopData = \App\Models\Application::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(request('application_status') == $status ? 'selected' : ''); ?>>
                            <?php echo e($status); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="document_status">Document Status</label>
                    <select name="document_status" class="form-select">
                        <option value="">All</option>
                        <option value="Incomplete" <?php echo e(request('document_status') == 'Incomplete' ? 'selected' : ''); ?>>Incomplete</option>
                        <option value="Completed" <?php echo e(request('document_status') == 'Completed' ? 'selected' : ''); ?>>Completed</option>
                        <option value="Not Uploaded" <?php echo e(request('document_status') == 'Not Uploaded' ? 'selected' : ''); ?>>Not Uploaded</option>
                    </select>
                </div>

                
                <div class="col-md-2 mt-2 d-flex gap-2">
                    <a href="<?php echo e(route('agent.students.index')); ?>" class="btn btn-secondary">Clear</a>
                    <button type="submit" class="btn btn-success">Find</button>
                </div>
            </div>
        </form>
    </div>

    
    <div class="table-card rounded shadow-sm p-3 bg-white">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h5">My Students</h2>
            <a href="<?php echo e(route('agent.students.create')); ?>" class="btn btn-primary">
                <i class="fa-solid fa-plus me-1"></i> Add Student
            </a>
        </div>
        <div class="table-responsive">
            <table class=" table table-striped align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Profile</th>
                        <th>Name</th>
                        <th>Email / Contact</th>
                        <th>Latest <br>Application Status</th>
                        <th>No of <br>Applications</th>
                        <th>Preferred Country</th>
                        <th>Qualification</th>
                        <th>Document Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                    // ----------------- Document Status -----------------
                    $predefinedDocuments = [
                    'passport',
                    '10th_certificate',
                    '10th_transcript',
                    '11th_transcript',
                    '12th_certificate',
                    '12th_transcript',
                    'cv',
                    'moi',
                    'lor',
                    'ielts_pte_language_certificate' ];

                    // Normalize uploaded document types
                    $uploadedTypes = $student->documents->pluck('document_type')
                    ->map(fn($t) => strtolower($t))
                    ->toArray();

                    // Check if all predefined documents are uploaded
                    $allDocumentsUploaded = count(array_diff($predefinedDocuments, $uploadedTypes)) === 0;

                    // Document status
                    $documentStatus = $allDocumentsUploaded
                    ? 'Completed'
                    : (count($uploadedTypes) == 0 ? 'Not Uploaded' : 'Incomplete');

                    // Latest application
                    $latestApplication = $student->applications->sortByDesc('created_at')->first();
                    ?>

                    <tr>
                        <td><?php echo e($student->id); ?></td>

                        
                        <td class="text-center">
                            <a href="<?php echo e(route('agent.students.show', $student->id)); ?>">
                                <?php if($student->students_photo && Storage::disk('public')->exists($student->students_photo)): ?>
                                <img src="<?php echo e(Storage::url($student->students_photo)); ?>" alt="Profile" class="rounded-circle border" style="width:50px; height:50px; object-fit:cover;">
                                <?php else: ?>
                                <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center border" style="width:50px; height:50px;">
                                    <i class="fa fa-user-circle text-white" style="font-size:24px;"></i>
                                </div>
                                <?php endif; ?>
                            </a>
                        </td>

                        
                        <td>
                            <a href="<?php echo e(route('agent.students.show', $student->id)); ?>">
                                <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?>

                            </a>
                        </td>

                        
                        <td>
                            <div><?php echo e($student->email); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($student->phone_number); ?></div>
                        </td>

                        
                        <td>
                            <?php if($latestApplication): ?>
                            <a href="<?php echo e(route('agent.applications.show', $latestApplication->id)); ?>">
                                <div class="px-2 py-1 rounded text-xs">
                                    <span class="badge <?php echo e($latestApplication->status_class); ?>">
                                        <?php echo e($latestApplication->application_status); ?>

                                    </span>
                                </div>
                            </a>
                            <?php else: ?>
                            <div class="px-2 py-1 rounded text-xs bg-light text-muted">No Application</div>
                            <?php endif; ?>
                        </td>

                        
                        <td>
                            <?php if($student->applications->count() > 0): ?>
                            <a href="<?php echo e(route('agent.students.applications', $student->id)); ?>">
                                <?php echo e($student->applications->count()); ?>

                            </a>
                            <?php else: ?>
                            0
                            <?php endif; ?>
                        </td>

                        
                        <td><?php echo e($student->preferred_country ?? 'N/A'); ?></td>

                        
                        <td><?php echo e($student->qualification ?? 'N/A'); ?></td>

                        
                        <td>
                            <a href="<?php echo e(route('agent.documents.index', $student->id)); ?>">
                                <?php if($documentStatus == 'Not Uploaded'): ?>
                                <div class="px-2 py-1 rounded text-xs bg-danger text-white">Not Uploaded</div>
                                <?php elseif($allDocumentsUploaded): ?>
                                <div class="px-2 py-1 rounded text-xs bg-success text-white">Completed</div>
                                <?php else: ?>
                                <div class="px-2 py-1 rounded text-xs bg-warning text-dark">Incomplete</div>
                                <?php endif; ?>
                            </a>
                        </td>

                        
                        <td class="d-flex flex-column gap-1">
                            <?php if($allDocumentsUploaded): ?>
                            <a href="<?php echo e(route('agent.applications.create')); ?>?student_id=<?php echo e($student->id); ?>" class="btn btn-sm btn-success mt-1">
                                <i class="fa-solid fa-paper-plane me-1"></i> Apply Now
                            </a>
                            <?php else: ?>
                            <a href="<?php echo e(route('agent.documents.index', $student->id)); ?>" class="btn btn-sm btn-outline-secondary mt-1">
                                <i class="fa-solid fa-folder-open me-1"></i> Upload Docs
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="text-center text-gray-500">No students found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($students->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\agent\students\index.blade.php ENDPATH**/ ?>