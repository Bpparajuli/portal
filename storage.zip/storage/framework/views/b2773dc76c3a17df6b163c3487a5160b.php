
<?php $__env->startSection('title', 'Manage Documents'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/document.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
        <div>
            <h3 class="mb-1">Manage Documents for <span class="text-primary"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></span></h3>
            <small class="text-muted">
                Agent: <a href="<?php echo e(route('admin.users.show', $student->agent->id)); ?>"><?php echo e($student->agent->business_name); ?></a> |
                <a href="<?php echo e(route('admin.students.show', $student->id)); ?>">View Student</a> |
                <a href="<?php echo e(route('admin.applications.index')); ?>?student_id=<?php echo e($student->id); ?>">View Applications</a>
            </small>
        </div>
        <a href="<?php echo e(route('admin.documents.downloadAll', $student->id)); ?>" class="btn btn-success btn-md">
            <i class="fa-solid fa-download"> Download All
            </i>
        </a>
    </div>

    <?php
    $counter = 1;
    ?>

    
    <h4>Compulsory Documents</h4>
    <div class="predefined-documents mb-4">
        <?php $__currentLoopData = $allDocumentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $uploaded = $predefinedDocs->firstWhere('document_type', $type);
        if($uploaded){
        $extension = pathinfo($uploaded->file_name, PATHINFO_EXTENSION);
        $isImage = in_array(strtolower($extension), ['jpg','jpeg','png','gif','webp']);
        $filePath = asset('storage/' . $uploaded->file_path);
        }
        ?>

        <div class="uploaded-item d-flex align-items-center justify-content-between border rounded p-2 mb-2 bg-light">
            
            <div class="doc-label" style="width: 25%;">
                <strong><?php echo e($counter); ?>. <?php echo e(ucwords(str_replace('_',' ',$type))); ?></strong>
            </div>

            
            <div class="doc-content text-center flex-grow-1" style="width: 50%;">
                <?php if(!$uploaded): ?>
                <div class="text-muted">Not uploaded yet</div>
                <?php else: ?>
                <div class="d-inline-flex align-items-center gap-2">
                    <a href="#" data-preview="<?php echo e($filePath); ?>">
                        <?php if($isImage): ?>
                        <img src="<?php echo e($filePath); ?>" style="width:50px; height:50px; object-fit:cover; border-radius:3px;">
                        <?php else: ?>
                        <i class="fa-solid fa-file-lines fa-lg text-muted"></i>
                        <?php endif; ?>
                    </a>
                    <span class="text-truncate" style="max-width: 200px;"><?php echo e(basename($uploaded->file_name)); ?></span>
                </div>
                <?php endif; ?>
            </div>

            
            <div class="actions text-end" style="width: 20%;">
                <?php if($uploaded): ?>
                <a href="<?php echo e(route('admin.documents.download', [$student->id, $uploaded->id])); ?>" class="btn text-primary btn-sm" title="Download">
                    <i class="fa-solid fa-download"></i>
                </a>
                <form action="<?php echo e(route('admin.documents.destroy', [$student->id, $uploaded->id])); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn text-danger btn-sm" title="Delete" onclick="return confirm('Delete this document?')">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php $counter++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <h4>Other Documents</h4>
    <div class="other-documents mb-4">
        
        <?php $__empty_1 = true; $__currentLoopData = $otherDocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
        $extension = pathinfo($doc->file_name, PATHINFO_EXTENSION);
        $isImage = in_array(strtolower($extension), ['jpg','jpeg','png','gif','webp']);
        $filePath = asset('storage/' . $doc->file_path);
        ?>
        <div class="uploaded-item d-flex align-items-center justify-content-between gap-2 mb-2 border rounded p-2 bg-light">
            
            <div class="doc-label" style="width: 25%;">
                <strong><?php echo e($counter); ?>. <?php echo e($doc->custom_name ?? $doc->document_type); ?></strong>
            </div>

            
            <div class="doc-content text-center flex-grow-1" style="width: 50%;">
                <a href="#" data-preview="<?php echo e($filePath); ?>">
                    <?php if($isImage): ?>
                    <img src="<?php echo e($filePath); ?>" style="max-width:50px; border-radius:3px;">
                    <?php else: ?>
                    <i class="fa-solid fa-file-lines fa-lg text-muted"></i>
                    <?php endif; ?>
                </a>
            </div>

            
            <div class="actions d-flex gap-1" style="width: 20%;">
                <a href="<?php echo e(route('admin.documents.download', [$student->id, $doc->id])); ?>" class="btn text-primary btn-sm" title="Download">
                    <i class="fa-solid fa-download"></i>
                </a>
                <form action="<?php echo e(route('admin.documents.destroy', [$student->id, $doc->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm text-danger" title="Delete" onclick="return confirm('Delete this document?')">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </form>
            </div>
        </div>
        <?php $counter++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-muted">No other documents uploaded yet.</p>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/admin/documents/index.blade.php ENDPATH**/ ?>