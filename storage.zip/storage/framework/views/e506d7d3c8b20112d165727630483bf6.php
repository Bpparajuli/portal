<?php $__env->startSection('admin-content'); ?>
<div class="container py-4">

    
    <div class="card mb-4 shadow-sm">
        <div class="card-body d-flex align-items-center">
            <div class="me-4">
                <?php if($user->business_logo): ?>
                <img src="<?php echo e(Storage::url($user->business_logo)); ?>" alt="Logo" width="120" height="120" class="rounded-circle border shadow-sm">
                <?php else: ?>
                <div class="no-logo">No Logo</div>
                <?php endif; ?>
            </div>
            <div>
                <h3 class="mb-1"><?php echo e($user->business_name); ?></h3>
                <p class="mb-0"><strong>Owner:</strong> <?php echo e($user->owner_name ?? 'N/A'); ?></p>
                <p class="mb-0"><strong>Contact:</strong> <?php echo e($user->contact ?? 'N/A'); ?></p>
                <p class="mb-0"><strong>Email:</strong> <?php echo e($user->email); ?></p>
                <p class="mb-0"><strong>Role:</strong> <?php echo e($user->is_admin ? 'Admin' : 'Agent'); ?></p>
                <span class="badge <?php echo e($user->active ? 'bg-success' : 'bg-secondary'); ?>">
                    <?php echo e($user->active ? 'Active' : 'Inactive'); ?>

                </span>
            </div>
        </div>
    </div>

    
    <div class="row mb-4 text-center">
        <div class="col-md-4">
            <div class="stat-card">
                <h4><?php echo e($user->students_count ?? 0); ?></h4>
                <p>Students</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <h4><?php echo e($user->applications_count ?? 0); ?></h4>
                <p>Total Applications</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <h4><?php echo e($user->pending_applications ?? 0); ?></h4>
                <p>Pending Applications</p>
            </div>
        </div>
    </div>

    
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-primary text-white">
            Students
        </div>
        <div class="card-body">
            <?php if(isset($students) && $students->count()): ?>
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Applications</th>
                        <th>Joined</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.students.show', $student->id)); ?>">
                                <?php echo e(trim($student->first_name . ' ' . $student->last_name)); ?>

                            </a>
                        </td>
                        <td><?php echo e($student->email); ?></td>
                        <td><?php echo e($student->applications_count); ?></td>
                        <td><?php echo e($student->created_at->format('M d, Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="text-muted">No students found for this agent.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            Applications
        </div>
        <div class="card-body">
            <?php if(isset($applications) && $applications->count()): ?>
            <table class="table table-bordered align-middle">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Course</th>
                        <th>University</th>
                        <th>Status</th>
                        <th>Submitted</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.applications.show', $app->id)); ?>">
                                <?php echo e($app->student->first_name . ' ' . $app->student->last_name); ?>

                            </a></td>
                        <td> <?php echo e($app->course->title ?? $app->course->name ?? 'N/A'); ?></td>
                        <td><?php echo e($app->university->name ?? 'N/A'); ?>

                        </td>
                        <td>
                            <span class="badge <?php echo e($app->status_class ?? 'bg-light text-muted'); ?>">
                                <?php echo e($app->application_status); ?>

                            </span>
                        </td>
                        <td><?php echo e($app->created_at->diffForHumans()); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="text-muted">No applications submitted by this agent’s students.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\users\show.blade.php ENDPATH**/ ?>