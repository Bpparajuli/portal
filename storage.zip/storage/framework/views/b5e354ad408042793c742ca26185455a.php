<?php $__env->startSection('content'); ?>
<div class="container py-4 uni-page">
    
    <?php echo $__env->make('partials.uni_filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="row mt-4 g-4">
        <?php $__empty_1 = true; $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 col-lg-3">
            <div class="uni-card shadow-sm border-0 rounded-3 h-100 d-flex flex-column justify-content-between">
                <div class="uni-card-header text-center p-3">
                    <a href="<?php echo e(route('admin.universities.show', $uni->id)); ?>">
                        <?php if($uni->university_logo): ?>
                        <img src="<?php echo e(asset('storage/uni_logo/'.$uni->university_logo)); ?>" class="uni-logo rounded shadow-sm" alt="<?php echo e($uni->name); ?>">
                        <?php else: ?>
                        <div class="no-logo bg-light border rounded p-4 text-muted">
                            <i class="fas fa-university fa-2x"></i>
                            <p class="small mt-2 mb-0">No Logo</p>
                        </div>
                        <?php endif; ?>
                    </a>
                </div>

                <div class="uni-card-body text-center px-3 pb-3">
                    <a href="<?php echo e(route('admin.universities.show', $uni->id)); ?>" class="text-decoration-none text-dark">
                        <h5 class="fw-bold mb-1"><?php echo e($uni->name); ?></h5>
                        <p class="text-secondary small mb-1"><?php echo e($uni->short_name ?? 'N/A'); ?></p>
                    </a>
                    <p class="mb-1"><i class="fas fa-map-marker-alt text-muted me-1"></i> <?php echo e($uni->city ?? 'N/A'); ?>, <?php echo e($uni->country); ?></p>

                    <?php if($uni->website): ?>
                    <p class="small">
                        <a href="<?php echo e($uni->website); ?>" target="_blank" class="uni-web-link text-decoration-none">
                            <i class="fas fa-globe me-1 text-info"></i><?php echo e($uni->website); ?>

                        </a>
                    </p>
                    <?php endif; ?>

                    <p class="small text-muted mb-2"><i class="fas fa-envelope me-1"></i><?php echo e($uni->contact_email ?? 'N/A'); ?></p>
                </div>

                <div class="uni-card-footer d-flex justify-content-between align-items-center border-top p-3">
                    <div>
                        <?php if($uni->courses->count()): ?>
                        <button class="btn btn-sm btn-outline-primary" onclick="openCourseModal(<?php echo e($uni->id); ?>)">
                            <i class="fas fa-book-open me-1"></i> <?php echo e($uni->courses->count()); ?> Courses
                        </button>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('admin.universities.edit', $uni->id)); ?>" class="btn btn-sm btn-outline-info" title="Edit">
                            <i class="fa fa-edit"></i>
                        </a>
                        <?php if(auth()->id() === 1): ?>
                        <form action="<?php echo e(route('admin.universities.destroy', $uni->id)); ?>" method="POST" onsubmit="return confirm('Delete this university?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Delete">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        
        <div id="courseModal<?php echo e($uni->id); ?>" class="uni-modal">
            <div class="uni-modal-content shadow-lg rounded">
                <span class="uni-modal-close" onclick="closeCourseModal(<?php echo e($uni->id); ?>)">&times;</span>
                <h4 class="mb-3 fw-bold"><i class="fas fa-book text-primary me-2"></i>Courses at <?php echo e($uni->name); ?></h4>
                <div class="table-responsive">
                    <table class="table table-hover align-middle table-bordered small">
                        <thead class="table-dark">
                            <tr>
                                <th>Code</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Duration</th>
                                <th>Fee</th>
                                <th>Intakes</th>
                                <th>MOI</th>
                                <th>Scholarships</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $uni->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($course->course_code); ?></td>
                                <td><?php echo e($course->title); ?></td>
                                <td><?php echo e($course->description ?? 'N/A'); ?></td>
                                <td><?php echo e($course->duration ?? 'N/A'); ?></td>
                                <td><?php echo e($course->fee); ?></td>
                                <td><?php echo e($course->intakes ?? 'N/A'); ?></td>
                                <td><?php echo e($course->moi_requirement ?? 'N/A'); ?></td>
                                <td><?php echo e($course->scholarships ?? 'N/A'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-center text-muted mt-5">No universities found.</p>
        <?php endif; ?>
    </div>

    
    <div class="pagination-wrap mt-5 d-flex justify-content-center">
        <?php echo e($universities->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function openCourseModal(id) {
        document.getElementById('courseModal' + id).style.display = 'block';
    }

    function closeCourseModal(id) {
        document.getElementById('courseModal' + id).style.display = 'none';
    }
    window.onclick = function(event) {
        document.querySelectorAll('.uni-modal').forEach(modal => {
            if (event.target == modal) modal.style.display = "none";
        });
    }

</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    /* --- Card Styling --- */
    .uni-card {
        transition: all 0.25s ease-in-out;
        background: #fff;
    }

    .uni-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
    }

    .uni-logo {
        max-height: 80px;
        object-fit: contain;
    }

    .btn-outline-primary {
        font-size: 0.85rem;
        border-radius: 20px;
    }

    .btn-outline-primary:hover {
        background-color: #0d6efd;
        color: #fff;
    }

    /* --- Modal --- */
    .uni-modal {
        display: none;
        position: fixed;
        z-index: 1050;
        padding-top: 70px;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .uni-modal-content {
        background-color: #fff;
        margin: auto;
        padding: 20px;
        width: 90%;
        max-width: 1000px;
        animation: fadeIn 0.3s;
    }

    .uni-modal-close {
        float: right;
        font-size: 1.5rem;
        font-weight: bold;
        color: #aaa;
        cursor: pointer;
    }

    .uni-modal-close:hover {
        color: #000;
    }

    /* --- Table --- */
    .table th,
    .table td {
        text-align: center;
        vertical-align: middle;
    }

    /* --- Pagination --- */
    .pagination-wrap .pagination {
        justify-content: center;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\universities\index.blade.php ENDPATH**/ ?>