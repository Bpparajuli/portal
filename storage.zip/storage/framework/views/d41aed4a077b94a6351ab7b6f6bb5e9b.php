

<?php $__env->startSection('agent-content'); ?>
<div class="container p-4">
    <h3>📑 My Applications</h3>
    <div class="table-responsive">
        <table class="table table-bordered mt-3 align-middle text-center">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>University</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>SOP</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($app->id); ?></td>
                    <td>
                        <a href="<?php echo e(route('agent.students.show', $app->student->id)); ?>">
                            <?php echo e(optional($app->student)->first_name); ?> <?php echo e(optional($app->student)->last_name); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('agent.universities.show', $app->university->id)); ?>">
                            <?php echo e($app->university->name ?? 'N/A'); ?>

                        </a>
                    </td>
                    <td><?php echo e($app->course->title ?? 'N/A'); ?></td>
                    <td>
                        <a href="<?php echo e(route('agent.applications.show', $app->id)); ?>">
                            <span class="badge <?php echo e($app->status_class ?? 'bg-secondary'); ?>">
                                <?php echo e($app->application_status); ?>

                            </span>
                        </a>
                    </td>
                    <td>
                        <?php if($app->sop_file): ?>
                        <a href="#" data-preview="<?php echo e(Storage::url($app->sop_file)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                            👁️ SOP
                        </a>
                        <?php else: ?>
                        <span class="text-muted">Not uploaded</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-flex align-items-center justify-content-center">
                            <a href="<?php echo e(route('agent.applications.edit', $app->id)); ?>" title="Edit">
                                <i class="fa fa-pencil-square" style="font-size: 30px;"></i>
                            </a>

                            <a href="<?php echo e(route('agent.applications.show', $app->id)); ?>" class="btn btn-sm p-2 btn-outline-secondary" title="View">
                                👁️
                            </a>

                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-3">
                        No applications yet.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-3">
        <?php echo e($applications->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/agent/applications/index.blade.php ENDPATH**/ ?>