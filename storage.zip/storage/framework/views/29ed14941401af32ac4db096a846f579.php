

<?php $__env->startSection('agent-content'); ?>
<div class="container p-4">
    <h3>📑 My Applications</h3>
    <div class="table-wrapper">

        <table class="table table-bordered mt-3 align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>University</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>SOP</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($app->id); ?></td>
                    <td><?php echo e(optional($app->student)->first_name); ?> <?php echo e(optional($app->student)->last_name); ?></td>
                    <td><?php echo e($app->university->name ?? 'N/A'); ?></td>
                    <td><?php echo e($app->course->title ?? 'N/A'); ?></td>
                    <td>
                        <span class="badge <?php echo e($app->status_class ?? 'bg-secondary'); ?>">
                            <?php echo e($app->application_status); ?>

                        </span>
                    </td>
                    <td>
                        <?php if($app->sop_file): ?>
                        <a href="#" data-preview="<?php echo e(Storage::url($app->sop_file)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                            👁️ SOP
                        </a>
                        <?php else: ?>
                        <span class="text-muted">Not uploaded</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('agent.applications.edit', $app->id)); ?>" class="btn btn-sm m-1 btn-dark">
                                ✏️
                            </a>
                            <a href="<?php echo e(route('agent.applications.show', $app->id)); ?>" class="btn btn-sm m-1 btn-secondary">
                                👁️
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-3">
                        No applications yet.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-3">
        <?php echo e($applications->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\agent\applications\index.blade.php ENDPATH**/ ?>