<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <div class="card shadow-lg border-0 mb-5">
        <div class="card-body p-4 d-flex flex-wrap justify-content-between align-items-center">
            <div class="mb-3 mb-md-0">
                <h2 class="fw-bold mb-2 text-primary">
                    <i class="fas fa-university me-2"></i> <?php echo e($university->name); ?>

                    <small class="text-muted">(<?php echo e($university->short_name ?? 'N/A'); ?>)</small>
                </h2>
                <p class="mb-1"><i class="fas fa-globe text-secondary me-2"></i><strong>Country:</strong> <?php echo e($university->country); ?></p>
                <p class="mb-1"><i class="fas fa-city text-secondary me-2"></i><strong>City:</strong> <?php echo e($university->city ?? 'N/A'); ?></p>
                <p class="mb-1"><i class="fas fa-envelope text-secondary me-2"></i><strong>Email:</strong> <?php echo e($university->contact_email ?? 'N/A'); ?></p>
                <p class="mb-1"><i class="fas fa-link text-secondary me-2"></i><strong>Website:</strong>
                    <a href="<?php echo e($university->website); ?>" target="_blank" class="text-decoration-none text-info"><?php echo e($university->website); ?></a>
                </p>
                <p class="mt-3 text-muted"><i class="fas fa-info-circle text-secondary me-2"></i><?php echo e($university->description ?? 'No description available.'); ?></p>
            </div>

            <div class="text-center">
                <?php if($university->university_logo): ?>
                <img src="<?php echo e(asset('storage/uni_logo/' . $university->university_logo)); ?>" alt="University Logo" class="img-fluid rounded shadow-sm border" style="max-height: 130px;">
                <?php else: ?>
                <div class="bg-light text-muted p-4 rounded">
                    <i class="fas fa-university fa-3x"></i>
                    <p class="mt-2 small">No Logo</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="card shadow-lg border-0 mb-5">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-bold text-secondary mb-0">
                <i class="fas fa-book-open me-2"></i> Courses Offered
            </h3>
            <a href="<?php echo e(route('admin.courses.create', ['university_id' => $university->id])); ?>" class="btn btn-primary shadow-sm">
                <i class="fas fa-plus me-2"></i> Add New Course
            </a>
        </div>

        
        <?php if($university->courses->count()): ?>
        <div class="table-responsive">
            <table class="table table-hover table-striped align-middle shadow-sm">
                <thead class="table-dark text-center">
                    <tr>
                        <th><i class="fas fa-hashtag me-1"></i> Code</th>
                        <th><i class="fas fa-book me-1"></i> Title</th>
                        <th><i class="fas fa-clock me-1"></i> Duration</th>
                        <th><i class="fas fa-dollar-sign me-1"></i> Fee</th>
                        <th><i class="fas fa-calendar-alt me-1"></i> Intakes</th>
                        <th><i class="fas fa-language me-1"></i> MOI</th>
                        <th><i class="fas fa-graduation-cap me-1"></i> Scholarships</th>
                        <th><i class="fas fa-cogs me-1"></i> Actions</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $university->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($course->course_code); ?></td>
                        <td class="fw-semibold"><?php echo e($course->title); ?></td>
                        <td><?php echo e($course->duration); ?></td>
                        <td><?php echo e($course->fee); ?></td>
                        <td><?php echo e($course->intakes); ?></td>
                        <td><?php echo e($course->moi_requirement); ?></td>
                        <td><?php echo e($course->scholarships ?? '-'); ?></td>
                        <td>
                            <div class="d-flex gap-1 ">
                                <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="btn btn-sm tetx-primary me-1">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if(auth()->id() === 1): ?>

                                <form action="<?php echo e(route('admin.courses.destroy', $course->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this course?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm text-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="alert alert-info shadow-sm">
            <i class="fas fa-exclamation-circle me-2"></i> No courses found for this university.
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/admin/universities/show.blade.php ENDPATH**/ ?>