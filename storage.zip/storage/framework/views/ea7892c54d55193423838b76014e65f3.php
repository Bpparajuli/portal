<link rel="stylesheet" href="<?php echo e(asset('css/university.css')); ?>">

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="card-title fw-bold mb-0">Find Your University</h5>
            <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->is_admin): ?>
            <div>
                <a href="<?php echo e(route('admin.universities.create')); ?>" class="btn btn-success btn-sm">
                    <i class="fas fa-university me-1"></i> + Add University
                </a>
                <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-success btn-sm">
                    <i class="fas fa-book-open me-1"></i> + Add Course
                </a>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php
        if (auth()->check()) {
        if (auth()->user()->is_admin) {
        $formAction = route('admin.universities.index');
        } elseif (auth()->user()->is_agent) {
        $formAction = route('agent.universities.index');
        } else {
        $formAction = route('guest.universities.index');
        }
        } else {
        $formAction = route('guest.universities.index');
        }
        ?>

        <form method="GET" action="<?php echo e($formAction); ?>">
            <div class="row g-3">
                
                <div class="col-md-4">
                    <label for="search" class="form-label fw-semibold">Search</label>
                    <input type="text" id="search" name="search" class="form-control" placeholder="University or Course">
                </div>

                
                <div class="col-md-2">
                    <label for="country" class="form-label fw-semibold">Country</label>
                    <select id="country" name="country" class="form-select" data-cities-url="<?php echo e(route('guest.get-cities', ':country')); ?>">
                        <option value="">All Countries</option>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country); ?>"><?php echo e($country); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="city" class="form-label fw-semibold">City</label>
                    <select id="city" name="city" class="form-select" data-universities-url="<?php echo e(route('guest.get-universities', ':city')); ?>">
                        <option value="">All Cities</option>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="university_id" class="form-label fw-semibold">University</label>
                    <select id="university_id" name="university_id" class="form-select" data-courses-url="<?php echo e(route('guest.get-courses', ':universityId')); ?>">
                        <option value="">All Universities</option>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="course_id" class="form-label fw-semibold">Course</label>
                    <select id="course_id" name="course_id" class="form-select">
                        <option value="">All Courses</option>
                    </select>
                </div>
            </div>

            
            <div class="mt-4 d-flex justify-content-end gap-2">
                <a href="<?php echo e(route('guest.universities.index')); ?>" class="btn btn-secondary">Clear</a>
                <button type="submit" class="btn btn-primary">Find</button>
            </div>
        </form>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo e(asset('js/filter.js')); ?>"></script>
<?php /**PATH C:\laragon\www\portal\resources\views\partials\uni_filter.blade.php ENDPATH**/ ?>