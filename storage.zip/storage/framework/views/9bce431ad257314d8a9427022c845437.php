

<?php $__env->startSection('title', 'Course Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Course Details</h4>
        <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> Back to Courses
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><?php echo e($course->title); ?></h5>
            <small><?php echo e($course->university->name ?? 'Unknown University'); ?></small>
        </div>

        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <h6 class="text-muted">University</h6>
                    <p class="fw-semibold"><?php echo e($course->university->name ?? 'N/A'); ?></p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">City</h6>
                    <p class="fw-semibold"><?php echo e($course->university->city ?? 'N/A'); ?></p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">Country</h6>
                    <p class="fw-semibold"><?php echo e($course->university->country ?? 'N/A'); ?></p>
                </div>
            </div>

            <hr>

            <div class="row mb-3">
                <div class="col-md-4">
                    <h6 class="text-muted">Course Code</h6>
                    <p class="fw-semibold"><?php echo e($course->course_code); ?></p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">Course Type</h6>
                    <p class="fw-semibold"><?php echo e($course->course_type); ?></p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">Duration</h6>
                    <p class="fw-semibold"><?php echo e($course->duration ?? 'N/A'); ?></p>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-4">
                    <h6 class="text-muted">Tuition Fee</h6>
                    <p class="fw-semibold">
                        <?php echo e($course->fee); ?>

                    </p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">Application Fee</h6>
                    <p class="fw-semibold"><?php echo e($course->application_fee ? '$' . $course->application_fee : 'N/A'); ?></p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">MOI Requirement</h6>
                    <p class="fw-semibold"><?php echo e($course->moi_requirement); ?></p>
                </div>
            </div>

            <div class="mb-3">
                <h6 class="text-muted">Intakes</h6>
                <p class="fw-semibold"><?php echo e($course->intakes ?? 'N/A'); ?></p>
            </div>

            <div class="mb-3">
                <h6 class="text-muted">Description</h6>
                <p><?php echo e($course->description ?? 'No description available.'); ?></p>
            </div>

            <div class="mb-3">
                <h6 class="text-muted">IELTS / PTE / Other Language Requirements</h6>
                <p><?php echo e($course->ielts_pte_other_languages ?? 'N/A'); ?></p>
            </div>

            <div class="mb-3">
                <h6 class="text-muted">Scholarships</h6>
                <p><?php echo e($course->scholarships ?? 'N/A'); ?></p>
            </div>

            <hr>

            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-muted">Created At</h6>
                    <p><?php echo e($course->created_at ? $course->created_at->format('Y-m-d H:i') : 'N/A'); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-muted">Last Updated</h6>
                    <p><?php echo e($course->updated_at ? $course->updated_at->format('Y-m-d H:i') : 'N/A'); ?></p>
                </div>
            </div>

            <div class="d-flex justify-content-end mt-4">
                <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="btn btn-primary me-2">
                    <i class="fas fa-edit"></i> Edit Course
                </a>

                <?php if(Auth::id() === 1): ?>
                <form action="<?php echo e(route('admin.courses.destroy', $course->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this course?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\courses\show.blade.php ENDPATH**/ ?>