<?php $__currentLoopData = $requiredDocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="doc-item">
    <strong><?php echo e($label); ?>:</strong>
    <?php if(isset($uploadedDocs[$key]) && count($uploadedDocs[$key]) > 0): ?>
    <span class="text-success">Uploaded ✅</span>
    <ul>
        <?php $__currentLoopData = $uploadedDocs[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(Storage::url($doc->file_path)); ?>" target="_blank"><?php echo e($doc->file_name); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php else: ?>
    <span class="text-danger">Missing ❌</span>
    <form action="<?php echo e(route('agent.documents.store', $student->id)); ?>" method="POST" enctype="multipart/form-data" class="upload-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="document_type" value="<?php echo e($key); ?>">
        <input type="file" name="file" required>
        <button type="submit" class="btn btn-sm btn-primary">Upload</button>
    </form>
    <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\portal\resources\views\partials\docs.blade.php ENDPATH**/ ?>