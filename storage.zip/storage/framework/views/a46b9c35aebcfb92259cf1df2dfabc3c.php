<?php $__env->startSection('content'); ?>
<div class="student-page container">

    
    <div class="filter-card mb-4 p-3 rounded shadow-sm">
        <form method="GET" action="<?php echo e(route('admin.students.index')); ?>" class="filter-form">
            <div class="row g-3 align-items-end">

                
                <div class="col-md-2">
                    <label for="search">Search by Name</label>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control">
                </div>

                
                <div class="col-md-2">
                    <label for="agent">Agent</label>
                    <select name="agent" class="form-select">
                        <option value="">All</option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($agent->id); ?>" <?php echo e(request('agent') == $agent->id ? 'selected' : ''); ?>>
                            <?php echo e($agent->business_name ?? $agent->username); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="status">Application Status</label>
                    <select name="status" class="form-select">
                        <option value="">All</option>
                        <?php $__currentLoopData = \App\Models\Student::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($status)); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="sort_by">Sort By</label>
                    <select name="sort_by" class="form-select">
                        <?php $__currentLoopData = ['created_at'=>'Created At','first_name'=>'First Name','email'=>'Email']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(request('sort_by')==$key ? 'selected' : ''); ?>><?php echo e($val); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label for="sort_order">Order</label>
                    <select name="sort_order" class="form-select">
                        <option value="ASC" <?php echo e(request('sort_order')=='ASC'?'selected':''); ?>>Ascending</option>
                        <option value="DESC" <?php echo e(request('sort_order','DESC')=='DESC'?'selected':''); ?>>Descending</option>
                    </select>
                </div>

                
                <div class="col-md-2 mt-2 d-flex gap-2">
                    <a href="<?php echo e(route('admin.students.index')); ?>" class="btn btn-secondary">Clear</a>
                    <button type="submit" class="btn btn-success">Search</button>
                </div>

            </div>
        </form>
    </div>

    
    <div class="table-card rounded shadow-sm p-3 bg-white">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h5">All Students</h2>
            <a href="<?php echo e(route('admin.students.create')); ?>" class="btn btn-primary">
                <i class="fa-solid fa-plus me-1"></i> Add Student
            </a>
        </div>
        <div class="table-responsive">
            <table class=" table table-striped align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Profile</th>
                        <th>Name</th>
                        <th>Email / Contact</th>
                        <th>Agent</th>
                        <th>Latest Application Status</th>
                        <th>No of Applications</th>
                        <th>Document Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                    // ----------------- Document Status -----------------
                    $predefinedDocuments = [
                    'passport','10th_certificate','10th_transcript','11th_transcript',
                    '12th_certificate','12th_transcript','cv','moi','lor','ielts_pte_language_certificate'
                    ];

                    $uploadedTypes = $student->documents->pluck('document_type')
                    ->map(fn($t) => strtolower($t))
                    ->toArray();

                    $allDocumentsUploaded = count(array_diff($predefinedDocuments, $uploadedTypes)) === 0;

                    $documentStatus = $allDocumentsUploaded
                    ? 'Completed'
                    : (count($uploadedTypes) == 0 ? 'Not Uploaded' : 'Incomplete');

                    $latestApplication = $student->applications->sortByDesc('created_at')->first();
                    ?>

                    <tr>
                        <td><?php echo e($student->id); ?></td>

                        
                        <td class="text-center">
                            <?php if($student->students_photo && Storage::disk('public')->exists($student->students_photo)): ?>
                            <img src="<?php echo e(Storage::url($student->students_photo)); ?>" alt="Profile" class="rounded-circle border" style="width:50px; height:50px; object-fit:cover;">
                            <?php else: ?>
                            <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center border" style="width:50px; height:50px;">
                                <i class="fa fa-user-circle text-white" style="font-size:24px;"></i>
                            </div>
                            <?php endif; ?>
                        </td>

                        
                        <td>
                            <a href="<?php echo e(route('admin.students.show', $student->id)); ?>">
                                <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?>

                            </a>
                        </td>

                        
                        <td>
                            <div><?php echo e($student->email); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($student->phone_number); ?></div>
                        </td>

                        
                        <td><?php echo e($student->agent?->business_name ?? $student->agent?->username ?? 'N/A'); ?></td>

                        
                        <td>
                            <?php if($latestApplication): ?>
                            <a href="<?php echo e(route('admin.applications.show', $latestApplication->id)); ?>">
                                <span class="badge <?php echo e($latestApplication->status_class); ?>">
                                    <?php echo e($latestApplication->application_status); ?>

                                </span>
                            </a>
                            <?php else: ?>
                            <span class="badge bg-light text-muted">No Application</span>
                            <?php endif; ?>
                        </td>

                        
                        <td>
                            <?php if($student->applications->count() > 0): ?>
                            <a href="<?php echo e(route('admin.students.applications', $student->id)); ?>">
                                <?php echo e($student->applications->count()); ?>

                            </a>
                            <?php else: ?>
                            0
                            <?php endif; ?>
                        </td>

                        
                        <td>
                            <a href="<?php echo e(route('admin.documents.index', $student->id)); ?>">
                                <?php if($documentStatus == 'Not Uploaded'): ?>
                                <div class="px-2 py-1 rounded text-xs bg-danger text-white">Not Uploaded</div>
                                <?php elseif($allDocumentsUploaded): ?>
                                <div class="px-2 py-1 rounded text-xs bg-success text-white">Completed</div>
                                <?php else: ?>
                                <div class="px-2 py-1 rounded text-xs bg-warning text-dark">Incomplete</div>
                                <?php endif; ?>
                            </a>
                        </td>

                        
                        <td>
                            <?php if($allDocumentsUploaded && $latestApplication): ?>
                            <a href="<?php echo e(route('admin.applications.show', $latestApplication->id)); ?>" class="p-2 btn btn-sm btn-light p-1">
                                <i class="fa-solid fa-tools me-1"></i> Update Status
                            </a>
                            <?php else: ?>
                            <a href="<?php echo e(route('admin.documents.index', $student->id)); ?>" class="p-2 btn btn-sm btn-outline-secondary mt-1">
                                <i class="fa-solid fa-folder-open me-1"></i> Upload Docs
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center text-gray-500">No students found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($students->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/admin/students/index.blade.php ENDPATH**/ ?>