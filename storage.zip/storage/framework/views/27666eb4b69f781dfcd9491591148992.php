

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    .notifications-grid {
        display: flex;
        gap: 20px;
        align-items: flex-start;
    }

    .notifications-grid>.main-column {
        flex: 1;
        /* left column takes all remaining space */
    }

    .notifications-grid>.sidebar-column {
        flex: 0 0 300px;
        /* fixed width sidebar */
    }

    .section-card {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    .notification-card {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        padding: 12px 15px;
        border: 1px solid #eee;
        border-radius: 10px;
        background: #fafafa;
        margin-bottom: 10px;
        transition: all 0.2s ease-in-out;
    }

    .notification-card.unread {
        background: #eaf3ff;
        border-left: 3px solid #007bff;
    }

    .notification-icon i {
        font-size: 1.5rem;
        color: #007bff;
    }

    .notification-body {
        flex-grow: 1;
        margin-left: 12px;
    }

    .notification-title {
        font-weight: 600;
    }

    .notification-text {
        font-size: 0.9rem;
        color: #555;
    }

    .notification-meta small {
        font-size: 0.8rem;
        color: #888;
    }

    .badge-new {
        background: #007bff;
        color: #fff;
        border-radius: 6px;
        padding: 2px 6px;
        font-size: 0.7rem;
        margin-left: 6px;
    }

    /* Responsive: stack columns */
    @media (max-width: 992px) {
        .notifications-grid {
            flex-direction: column;
        }

        .notifications-grid>.sidebar-column {
            flex: 1 1 100%;
        }
    }

</style>

<div class="notifications-container">
    <!-- Header -->
    <div class="page-header mb-4 d-flex justify-content-between align-items-center">
        <h1 class="page-title"><i class="fa fa-bell me-2"></i> Admin Notifications</h1>
        <form action="<?php echo e(route('admin.notifications.markAll')); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <button class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
                <i class="fa fa-check-double"></i> Mark All as Read
            </button>
        </form>
    </div>

    <?php if(session('status')): ?>
    <div class="alert alert-success mb-4"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <?php if($notifications->count()): ?>
    <?php
    $messages = [];
    $otherNotifications = [];

    foreach($notifications as $notification) {
    $data = (array) ($notification->data ?? []);
    if(($data['type'] ?? '') === 'application_message_added') {
    $messages[] = $notification;
    } else {
    $otherNotifications[] = $notification;
    }
    }

    $typeTitles = [
    'student_added' => 'Student Added',
    'student_deleted' => 'Student Deleted',
    'student_status' => 'Student Status Updated',
    'application_submitted' => 'Application Submitted',
    'application_status' => 'Application Status Updated',
    'application_withdrawn' => 'Application Withdrawn',
    'document_uploaded' => 'Document Uploaded',
    'document_deleted' => 'Document Deleted',
    'user_registered' => 'User Registered',
    'other' => 'Other Notifications',
    ];

    $grouped = collect($otherNotifications)->groupBy(fn($n) => ($n->data['type'] ?? 'other'));
    ?>

    <div class="notifications-grid">
        <!-- Left Column: Other Notifications -->
        <div class="main-column">
            <?php $__empty_1 = true; $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $notificationsOfType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mb-5 section-card">
                <h4 class="section-title d-flex align-items-center justify-content-between">
                    <span>
                        <i class="fa <?php echo e(match(true) {
                                        str_contains($type, 'student') => 'fa-user',
                                        str_contains($type, 'application') => 'fa-file-alt',
                                        str_contains($type, 'document') => 'fa-paperclip',
                                        default => 'fa-bell'
                                    }); ?>"></i>
                        <?php echo e($typeTitles[$type] ?? ucfirst(str_replace('_', ' ', $type))); ?>

                    </span>
                    <span class="text-muted">(<?php echo e($notificationsOfType->count()); ?>)</span>
                </h4>

                <?php $__currentLoopData = $notificationsOfType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $isUnread = is_null($notification->read_at);
                $data = (array) ($notification->data ?? []);
                $message = $data['message'] ?? $data['title'] ?? $data['body'] ?? 'Notification';
                $created = $notification->created_at?->diffForHumans();
                $short = $data['short'] ?? $data['details'] ?? null;
                $url = $data['link'] ?? $data['url'] ?? null;
                if (!$url && !empty($data['application_id'])) $url = route('admin.applications.show', $data['application_id']);
                elseif (!$url && !empty($data['student_id'])) $url = route('admin.students.show', $data['student_id']);
                $icon = match(true) {
                str_contains($type, 'student_status') => 'fa-user-check',
                str_contains($type, 'application_status') => 'fa-file-circle-check',
                str_contains($type, 'student_deleted') => 'fa-user-slash',
                str_contains($type, 'application_withdrawn') => 'fa-ban',
                str_contains($type, 'document') => 'fa-paperclip',
                default => 'fa-bell'
                };
                ?>

                <?php if($url): ?><a href="<?php echo e($url); ?>" class="notification-link"><?php endif; ?>
                    <div class="notification-card <?php echo e($isUnread ? 'unread' : ''); ?>">
                        <div class="notification-icon"><i class="fa <?php echo e($icon); ?>"></i></div>
                        <div class="notification-body">
                            <p class="notification-title"><?php echo $message; ?></p>
                            <?php if($short): ?><p class="notification-text"><?php echo e(Str::limit($short, 130)); ?></p><?php endif; ?>
                            <div class="notification-meta">
                                <small><i class="fa fa-clock me-1"></i> <?php echo e($created); ?></small>
                                <?php if($isUnread): ?><span class="badge-new">New</span><?php endif; ?>
                            </div>
                        </div>
                        <div class="notification-actions" onclick="event.stopPropagation();">
                            <?php if($isUnread): ?>
                            <form action="<?php echo e(route('admin.notifications.markRead', $notification->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn-icon" title="Mark as read"><i class="fa fa-check"></i></button>
                            </form>
                            <?php else: ?>
                            <form action="<?php echo e(route('admin.notifications.markUnread', $notification->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn-icon" title="Mark as unread"><i class="fa fa-undo"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if($url): ?></a><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state section-card text-center py-4">
                <i class="fa fa-bell-slash"></i>
                <p>No notifications in this category.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Right Column: Application Messages -->
        <div class="sidebar-column section-card">
            <h4 class="section-title"><i class="fa fa-envelope"></i> Messages
                <?php if(count($messages)): ?> <span class="text-muted ms-auto">(<?php echo e(count($messages)); ?>)</span> <?php endif; ?>
            </h4>

            <?php if(count($messages)): ?>
            <ul class="messages-list list-unstyled">
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $isUnread = is_null($notification->read_at);
                $data = (array) ($notification->data ?? []);
                $senderName = $data['user_name'] ?? 'Unknown User';
                $message = $data['message'] ?? 'No message';
                $created = $notification->created_at?->diffForHumans();
                $url = $data['link'] ?? null;
                ?>

                <?php if($url): ?><a href="<?php echo e($url); ?>" class="notification-link"><?php endif; ?>
                    <li class="notification-card <?php echo e($isUnread ? 'unread' : ''); ?> p-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1 me-3">
                                <p class="notification-title mb-1"><?php echo $message; ?></p>
                                <small class="text-muted">
                                    <i class="fa fa-clock"></i> <?php echo e($created); ?>

                                    <?php if($isUnread): ?><span class="badge-new ms-2">New</span> By: <?php echo e($senderName); ?><?php endif; ?>
                                </small>
                            </div>
                            <div class="notification-actions" onclick="event.stopPropagation();">
                                <?php if($isUnread): ?>
                                <form action="<?php echo e(route('admin.notifications.markRead', $notification->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn-icon" title="Mark as read"><i class="fa fa-check"></i></button>
                                </form>
                                <?php else: ?>
                                <form action="<?php echo e(route('admin.notifications.markUnread', $notification->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn-icon" title="Mark as unread"><i class="fa fa-undo"></i></button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </li>
                    <?php if($url): ?></a><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
            <div class="empty-state text-center py-4">
                <i class="fa fa-envelope-open"></i>
                <p>No messages yet.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Pagination -->
    <div class="mt-5 d-flex justify-content-center">
        <?php echo e($notifications->links()); ?>

    </div>

    <?php else: ?>
    <div class="section-card text-center py-6">
        <div class="empty-state">
            <i class="fa fa-bell-slash"></i>
            <p class="mb-0 mt-3">No notifications yet. You're all caught up!</p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/admin/notifications.blade.php ENDPATH**/ ?>