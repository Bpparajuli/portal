<?php $__env->startSection('content'); ?>
<div class=" p-4">
    <h2>Edit University</h2>

    <form action="<?php echo e(route('admin.universities.update', $university->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('admin.universities.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <button type="submit" class="btn btn-success">Update University</button>
        <a href="<?php echo e(route('admin.universities.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>

    <hr>
    <h3>Courses at <?php echo e($university->short_name ?? $university->name); ?></h3>
    <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary mb-3">Add New Course</a>

    <?php if($university->courses->count()): ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Course Code</th>
                <th>Title</th>
                <th>Duration</th>
                <th>Fee</th>
                <th>Intakes</th>
                <th>MOI Requirement</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $university->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($course->course_code); ?></td>
                <td><?php echo e($course->title); ?></td>
                <td><?php echo e($course->duration); ?></td>
                <td><?php echo e($course->fee); ?></td>
                <td><?php echo e($course->intakes); ?></td>
                <td><?php echo e($course->moi_requirement); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                    <form action="<?php echo e(route('admin.courses.destroy', $course->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this course?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>No courses found for this university.</p>
    <?php endif; ?>
    <a href="<?php echo e(route('admin.universities.index')); ?>" class="btn btn-secondary">Back to Universities list</a>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\universities\edit.blade.php ENDPATH**/ ?>