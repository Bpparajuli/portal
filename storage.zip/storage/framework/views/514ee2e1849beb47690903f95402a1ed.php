
<div data-component="sidebar">
    <div class="sidebar">
        <ul class="list-group flex-column d-inline-block first-menu">
            <?php if($user?->is_admin): ?>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fa fa-house" aria-hidden="true"><span class="ml-2 align-middle">Dashboard</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('student/index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.students.index')); ?>">
                    <i class="fa fa-users" aria-hidden="true"><span class="ml-2 align-middle">Students</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('universities/index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.universities.index')); ?>">
                    <i class="fa fa-calendar-check" aria-hidden="true"><span class="ml-2 align-middle">Universities</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('user/index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.users.index')); ?>">
                    <i class="fa fa-sliders" aria-hidden="true"><span class="ml-2 align-middle">Users</span></i>
                </a>
            </li>
            <?php
            $totalWaitingUsers = \App\Models\User::where('active', 0)->count();
            ?>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('user/waiting') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.users.waiting')); ?>">
                    <i class="fa fa-question" aria-hidden="true">
                        <?php if($totalWaitingUsers > 0): ?>
                        <span class="badge bg-danger rounded-pill ml-1"><?php echo e($totalWaitingUsers); ?></span>
                        <?php endif; ?>
                        <span class="ml-2 align-middle">Waiting Users</span>
                    </i>
                </a>
            </li>

            <?php elseif($user?->is_agent): ?>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('agent/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('agent.dashboard')); ?>">
                    <i class="fa fa-house" aria-hidden="true"><span class="ml-2 align-middle">Dashboard</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('student/index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('agent.students.index')); ?>">
                    <i class="fa fa-users" aria-hidden="true"><span class="ml-2 align-middle">Students</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('university/index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('agent.universities.index')); ?>">
                    <i class="fa fa-calendar-check" aria-hidden="true"><span class="ml-2 align-middle">Universities</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('user/list') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('agent.students.index')); ?>">
                    <i class="fa fa-sliders" aria-hidden="true"><span class="ml-2 align-middle">Applied List</span></i>
                </a>
            </li>

            <?php else: ?>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/')); ?>">
                    <i class="fa fa-house" aria-hidden="true"><span class="ml-2 align-middle">Dashboard</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2">
                <a href="https://ideaconsultancyservices.com/">
                    <i class="fa fa-globe" aria-hidden="true"><span class="ml-2 align-middle">Webpage</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('university/index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('guest.universities.index')); ?>">
                    <i class="fa fa-calendar-check" aria-hidden="true"><span class="ml-2 align-middle">Universities</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('contact/show') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('auth.contact')); ?>">
                    <i class="fa fa-envelope" aria-hidden="true"><span class="ml-2 align-middle">Contact Us</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('login') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('login')); ?>">
                    <i class="fa fa-sign-in" aria-hidden="true"><span class="ml-2 align-middle">Login</span></i>
                </a>
            </li>
            <li class="list-group-item pl-3 py-2 <?php echo e(request()->is('register') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('register')); ?>">
                    <i class="fa fa-user-plus" aria-hidden="true"><span class="ml-2 align-middle">Register</span></i>
                </a>
            </li>
            <?php endif; ?>

            <?php if($user): ?>
            <li class="list-group-item pl-3 py-2">
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="m-0 p-0">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">
                        <i class="fa fa-sign-out" aria-hidden="true"><span class="ml-2 align-middle">Logout</span></i>
                    </a>
                </form>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
</nav>
<?php /**PATH C:\laragon\www\portal\resources\views\partials\sidebar.blade.php ENDPATH**/ ?>