

<?php $__env->startSection('admin-content'); ?>
<div class="dashboard-container p-3">

    
    <div class="row g-3 mb-4">
        <?php
        $cards = [
        ['title'=>'Agents', 'count'=>$totalAgents, 'icon'=>'fas fa-users', 'theme'=>'bg-primary-theme', 'link'=>route('admin.users.index')],
        ['title'=>'Students', 'count'=>$totalStudents, 'icon'=>'fas fa-graduation-cap', 'theme'=>'bg-secondary-theme', 'link'=>route('admin.students.index')],
        ['title'=>'Universities', 'count'=>$totalUniversities, 'icon'=>'fas fa-building', 'theme'=>'bg-success-theme', 'link'=>route('admin.universities.index')],
        ['title'=>'Courses', 'count'=>$totalCourses, 'icon'=>'fas fa-book-open', 'theme'=>'bg-primary-theme', 'link'=>route('admin.courses.index')],
        ['title'=>'Applications', 'count'=>$totalApplications, 'icon'=>'fas fa-file-alt', 'theme'=>'bg-success-theme', 'link'=>route('admin.applications.index')],
        ['title'=>'Waiting Users', 'count'=>$totalWaitingUsers, 'icon'=>'fas fa-clock', 'theme'=>'bg-secondary-theme', 'link'=>route('admin.users.waiting')],
        ];
        ?>

        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-4 col-xl-2">
            <a href="<?php echo e($card['link']); ?>" class="text-decoration-none">
                <div class="widget-card p-3 hover-scale">
                    <div class="icon-and-link mb-2">
                        <div>
                            <p class="widget-title mb-1"><?php echo e($card['title']); ?></p>
                            <div class="widget-value"><?php echo e(number_format($card['count'])); ?></div>
                        </div>
                        <div class="widget-icon <?php echo e($card['theme']); ?>">
                            <i class="<?php echo e($card['icon']); ?>"></i>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <small class="text-muted">View details</small>
                        <i class="fas fa-arrow-right"></i>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="row mb-4">
        <div class="col-12">
            <div class="action-card d-flex align-items-center justify-content-between">
                <div>
                    <h5 class="mb-0">Quick Actions</h5>
                    <small class="text-muted">Create or manage core items quickly</small>
                </div>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('admin.universities.create')); ?>" class="btn btn-success btn-sm"><i class="fas fa-university me-1"></i> Add University</a>
                    <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-success btn-sm"><i class="fas fa-book-open me-1"></i> Add Course</a>
                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success btn-sm"><i class="fas fa-user me-1"></i> Add User</a>
                    <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn btn-warning btn-sm"><i class="fas fa-tools me-1"></i> Manage Applications</a>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row g-4 mb-4">
        
        <div class="col-lg-8 d-flex flex-column gap-4">
            <div class="card chart-card flex-fill shadow-sm">
                <div class="card-body">
                    <h5>Monthly Applications</h5>
                    <canvas id="applicationsChart"></canvas>
                </div>
            </div>
            <div class="card chart-card flex-fill shadow-sm">
                <div class="card-body">
                    <h5>Applications by Country</h5>
                    <canvas id="countryChart"></canvas>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4 d-flex flex-column gap-4">
            <div class="card chart-card flex-fill shadow-sm">
                <div class="card-body">
                    <h5>Applications by Status</h5>
                    <canvas id="statusChart"></canvas>
                    <div class="progress-stats grid-two-columns mt-3">
                        <?php $__currentLoopData = $statusChartData['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="stat" style="background-color: <?php echo e($statusChartData['datasets'][0]['backgroundColor'][$i]); ?>; color: #fff; font-weight: bold;">
                            <?php echo e($s); ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>

            
            <div class="card top-agents-card flex-fill shadow-sm">
                <div class="card-body">
                    <h5>🏆 Top Agents</h5>
                    <ul class="list-group list-group-flush">
                        <?php $__empty_1 = true; $__currentLoopData = $topAgents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <?php if($agent->business_logo): ?>
                                <img src="<?php echo e(Storage::url($agent->business_logo)); ?>" class="rounded-circle" width="40" height="40">
                                <?php endif; ?>
                                <span><?php echo e($agent->name); ?></span>
                            </div>
                            <span class="badge bg-primary rounded-pill"><?php echo e($agent->applications_count); ?> Apps</span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-center text-muted">No top agents yet</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <h5>Recent Applications</h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-borderless align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Applicant</th>
                            <th>Agent</th>
                            <th>Course</th>
                            <th>University</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $latestApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.students.show', $app->student->id)); ?>">
                                    <?php echo e($app->student->first_name ?? 'N/A'); ?> <?php echo e($app->student->last_name ?? 'N/A'); ?>

                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.users.show', $app->agent->id)); ?>">
                                    <?php echo e($app->agent->name ?? 'N/A'); ?>

                                </a>
                            </td>
                            <td><?php echo e($app->course->title ?? 'N/A'); ?></td>
                            <td><?php echo e($app->university->name ?? 'N/A'); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.applications.show', $app->id)); ?>">
                                    <span class="badge <?php echo e($app->status_class); ?>">
                                        <?php echo e($app->application_status); ?>

                                    </span>
                                </a> </td>
                            <td>
                                <div class="d-flex gap-1">
                                    <a href="<?php echo e(route('admin.applications.show', $app->id)); ?>" class="p-2 btn btn-sm btn-primary">View</a>
                                    <button class="p-2 btn btn-sm btn-secondary">Delete</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">No recent applications</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="row g-3">

        
        <div class="col-md-4">
            <div class="card p-3 h-100">
                <h6 class="mb-3">Student Activities</h6>

                <ul class="list-unstyled m-0">

                    <?php $__empty_1 = true; $__currentLoopData = $studentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e($act->link); ?>" class="activity-link d-flex justify-content-between align-items-center">
                        <li class="mb-3">

                            
                            <div class="fw-semibold">
                                <?php echo $act->description; ?>

                            </div>

                            
                            <div class="d-flex justify-content-between text-muted small mt-1">
                                <span><?php echo e($act->user->business_name); ?></span>
                                <span><?php echo e($act->created_at->diffForHumans()); ?></span>
                            </div>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li>No student activities</li>
                        <?php endif; ?>
                    </a>
                </ul>

            </div>
        </div>


        
        <div class="col-md-4">
            <div class="card p-3 h-100">
                <h6 class="mb-3">Application Activities</h6>

                <ul class="list-unstyled m-0">
                    <?php $__empty_1 = true; $__currentLoopData = $applicationActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e($act->link); ?>" class="activity-link d-flex justify-content-between align-items-center">
                        <li class="mb-3">

                            
                            <div class="fw-semibold">
                                <?php echo $act->description; ?>

                            </div>

                            
                            <div class="d-flex justify-content-between text-muted small mt-1">
                                <span><?php echo e($act->user->business_name); ?></span>
                                <span><?php echo e($act->created_at->diffForHumans()); ?></span>
                            </div>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li>No application activities</li>
                        <?php endif; ?>
                    </a>
                </ul>
            </div>
        </div>


        
        <div class="col-md-4">
            <div class="card p-3 h-100">
                <h6 class="mb-3">Document Activities</h6>

                <ul class="list-unstyled m-0">
                    <?php $__empty_1 = true; $__currentLoopData = $documentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e($act->link); ?>" class="activity-link d-flex justify-content-between align-items-center">
                        <li class="mb-3">

                            
                            <div class="fw-semibold">
                                <?php echo $act->description; ?>

                            </div>

                            
                            <div class="d-flex justify-content-between text-muted small mt-1">
                                <span><?php echo e($act->user->business_name); ?></span>
                                <span><?php echo e($act->created_at->diffForHumans()); ?></span>
                            </div>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li>No document activities</li>
                        <?php endif; ?>
                    </a>
                </ul>

            </div>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        new Chart(document.getElementById('applicationsChart'), {
            type: 'line'
            , data: <?php echo json_encode($applicationsChartData, 15, 512) ?>
            , options: {
                responsive: true
                , tension: 0.3
                , plugins: {
                    legend: {
                        display: false
                    }
                }
                , scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        new Chart(document.getElementById('statusChart'), {
            type: 'doughnut'
            , data: <?php echo json_encode($statusChartData, 15, 512) ?>
            , options: {
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        new Chart(document.getElementById('countryChart'), {
            type: 'bar'
            , data: <?php echo json_encode($countryChartData, 15, 512) ?>
            , options: {
                responsive: true
                , plugins: {
                    legend: {
                        display: false
                    }
                }
                , scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>