<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\CrmTasks;
use App\Models\Student;
use App\Models\StudentNote;
use App\Models\StudentStage;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Services\StudentService;

class CrmStudentController extends Controller
{
    // =========================================================================
    // SHOW — full CRM student detail page
    // =========================================================================

    public function show(Student $student)
    {
        try {
            $this->authorizeStudent($student);

            $student->load([
                'currentStage',
                'agent',
                'documents',
                'latestApplication',
            ]);

            // Get tasks that are due (past due date but not completed)
            $dueTasks = CrmTasks::where('student_id', $student->id)
                ->where('status', '!=', 'completed')
                ->where('status', '!=', 'cancelled')
                ->whereNotNull('scheduled_at')
                ->where('scheduled_at', '<', now()->startOfDay())
                ->orderBy('scheduled_at', 'asc')
                ->get();

            // Today's pending tasks for this student
            $todayTasks = CrmTasks::where('student_id', $student->id)
                ->where('status', '!=', 'completed')
                ->where('status', '!=', 'cancelled')
                ->whereDate('scheduled_at', now()->toDateString())
                ->orderBy('scheduled_at', 'asc')
                ->get();

            // Planned future tasks (and tasks with no date)
            $plannedTasks = CrmTasks::where('student_id', $student->id)
                ->where('status', '!=', 'completed')
                ->where('status', '!=', 'cancelled')
                ->whereDate('scheduled_at', '>', now()->toDateString())
                ->orderBy('scheduled_at', 'asc')
                ->get();

            // Completed activity history — newest first
            $activityHistory = CrmTasks::where('student_id', $student->id)
                ->where('status', 'completed')
                ->with('assignee', 'creator')
                ->latest('completed_at')
                ->paginate(10);

            // Get COMPLETED and CANCELLED tasks (done history)
            $completedTasks = CrmTasks::where('student_id', $student->id)
                ->whereIn('status', ['completed', 'cancelled'])
                ->orderBy('completed_at', 'desc')
                ->paginate(10);

            // Internal notes — pinned first, then latest
            $notes = $student->notes()
                ->where('is_log', false)
                ->with('creator')
                ->orderBy('is_pinned', 'desc')
                ->orderBy('created_at', 'desc')
                ->get();

            // Get activity logs (separate)
            $activityLogs = $student->notes()
                ->where('is_log', true)
                ->with('creator')
                ->orderBy('created_at', 'desc')
                ->get();

            $staffUsers = User::where('role', 'staff')
                ->orderBy('name')
                ->get(['id', 'name', 'role', 'business_logo']);

            $stages       = StudentStage::active()->ordered()->get();
            $currentStage = $student->currentStage;

            // Users available for task assignment
            $user            = Auth::user();
            $assignableUsers = collect();

            if ($user->is_admin || $user->is_admin_staff) {
                $assignableUsers = User::whereIn('role', ['admin', 'agent', 'staff'])
                    ->select('id', 'name', 'role')
                    ->orderBy('name')
                    ->get();
            } elseif ($user->is_agent) {
                // Agent sees themselves + their staff
                $assignableUsers = User::where(function ($q) use ($user) {
                    $q->where('id', $user->id)
                        ->orWhere(function ($sq) use ($user) {
                            $sq->where('parent_id', $user->id)->where('role', 'staff');
                        });
                })->select('id', 'name', 'role')->get();
            } elseif ($user->is_agent_staff) {
                // Agent's staff sees themselves + their parent agent
                $assignableUsers = User::whereIn('id', [$user->id, $user->parent_id])
                    ->select('id', 'name', 'role')
                    ->get();
            } else {
                // Fallback staff → only themselves
                $assignableUsers = User::where('id', $user->id)->select('id', 'name', 'role')->get();
            }

            // canEdit: anyone except agents (agents are read-only in CRM)
            $canEdit = ! $user->is_agent;

            return view('crm.show', compact(
                'student',
                'dueTasks',
                'todayTasks',
                'plannedTasks',
                'activityHistory',
                'completedTasks',
                'notes',
                'activityLogs',
                'stages',
                'currentStage',
                'assignableUsers',
                'canEdit',
                'staffUsers'
            ));
        } catch (\Exception $e) {
            Log::error('Error in CrmStudentController@show: ' . $e->getMessage());
            return back()->with('error', 'Failed to load student details: ' . $e->getMessage());
        }
    }

    /**
     * Show edit form for student
     */


    public function edit(Student $student)
    {
        $this->authorizeStudent($student);

        // Get assignable agents for dropdown
        $user = Auth::user();
        $agents = collect();

        if ($user->is_admin || $user->is_admin_staff) {
            $agents = User::where('role', 'agent')->orderBy('business_name')->get();
        } elseif ($user->is_agent) {
            $agents = User::where('id', $user->id)->get();
        }

        return view('crm.student-edit', compact('student', 'agents'));
    }

    public function update(Request $request, Student $student)
    {
        try {
            $this->authorizeStudent($student);
            $this->denyAgents();

            $validated = $request->validate([
                'first_name' => ['required', 'string', 'max:100'],
                'last_name' => ['required', 'string', 'max:100'],
                'email' => ['nullable', 'email', 'max:255'],
                'phone_number' => ['nullable', 'string', 'max:20'],
                'dob' => ['nullable', 'date'],
                'gender' => ['nullable', 'string', 'in:Male,Female,Other'],
                'marital_status' => ['nullable', 'string', 'in:Single,Married,Other'],
                'students_photo' => ['nullable', 'image', 'max:5120'],
                'permanent_address' => ['nullable', 'string'],
                'temporary_address' => ['nullable', 'string'],
                'nationality' => ['nullable', 'string', 'max:100'],
                'passport_number' => ['nullable', 'string', 'max:50'],
                'passport_expiry' => ['nullable', 'date'],
                'qualification' => ['nullable', 'string', 'max:255'],
                'passed_year' => ['nullable', 'integer', 'min:1900', 'max:' . date('Y')],
                'education_board' => ['nullable', 'string', 'max:255'],
                'last_grades' => ['nullable', 'string', 'max:50'],
                'gap' => ['nullable', 'integer', 'min:0', 'max:50'],
                'preferred_country' => ['nullable', 'string', 'max:100'],
                'preferred_city' => ['nullable', 'string', 'max:100'],
                'preferred_course' => ['nullable', 'string', 'max:255'],
                'preferred_university' => ['nullable', 'string', 'max:255'],
                'remarks' => ['nullable', 'string'],
                'rating' => ['nullable', 'integer', 'min:1', 'max:3'],
                'agent_id' => ['nullable', 'exists:users,id'],
            ]);

            // Use StudentService to handle the update (ensures folder structure)
            $updatedStudent = StudentService::saveStudent($request, $student);

            return redirect()->route('crm.student.show', $updatedStudent)
                ->with('success', 'Student information updated successfully.');
        } catch (\Exception $e) {
            Log::error('Student update failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to update student: ' . $e->getMessage())->withInput();
        }
    }
    // =========================================================================
    // SAVE NOTE
    // =========================================================================

    public function saveNote(Request $request, Student $student)
    {
        try {
            $this->authorizeStudent($student);
            $this->denyAgents();

            $validated = $request->validate([
                'content'   => ['required', 'string'],
                'is_pinned' => ['boolean'],
            ]);

            StudentNote::create([
                'student_id' => $student->id,
                'created_by' => Auth::id(),
                'content'    => $validated['content'],
                'type'       => 'internal',
                'is_pinned'  => $request->boolean('is_pinned', false),
            ]);

            if ($request->ajax()) {
                return response()->json(['success' => true, 'message' => 'Note saved.']);
            }
            return back()->with('success', 'Note saved.');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    // =========================================================================
    // CHANGE STAGE
    // =========================================================================

    public function changeStage(Request $request, Student $student)
    {
        try {
            $this->authorizeStudent($student);
            $this->denyAgents();

            $validated = $request->validate([
                'new_stage_id' => ['required', 'exists:student_stages,id'],
                'reason'       => ['nullable', 'string', 'max:500'],
            ]);

            if ($student->currentStage && !$student->currentStage->canMoveToStage($validated['new_stage_id'])) {
                return back()->withErrors(['new_stage_id' => 'This transition is not allowed from the current stage.']);
            }

            $student->moveToStage($validated['new_stage_id'], $validated['reason'] ?? null);

            if ($request->ajax()) {
                return response()->json(['success' => true, 'message' => 'Stage updated.']);
            }
            return back()->with('success', 'Stage updated.');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function updateRating(Request $request, $id)
    {
        try {
            $request->validate([
                'rating' => 'nullable|integer|min:1|max:3',
            ]);

            $student = Student::findOrFail($id);

            // Check authorization
            $user = Auth::user();
            if (!$this->checkAccess($user, $student)) {
                return response()->json(['success' => false, 'error' => 'Unauthorized'], 403);
            }

            $student->rating = $request->rating;
            $student->save();

            return response()->json([
                'success' => true,
                'message' => 'Student rating updated successfully.',
                'rating' => $student->rating
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    private function authorizeStudent(Student $student): void
    {
        $user = Auth::user();

        if ($user->is_admin) return;
        if ($user->is_admin_staff) return;

        if ($user->is_agent) {
            $staffIds = User::where('parent_id', $user->id)->where('role', 'staff')->pluck('id');
            abort_unless(
                $student->agent_id === $user->id || $staffIds->contains($student->agent_id),
                403,
                'Unauthorized access to student record'
            );
            return;
        }

        if ($user->is_agent_staff) {
            abort_unless(in_array($student->agent_id, [$user->id, $user->parent_id]), 403, 'Unauthorized access');
            return;
        }

        // Fallback staff
        if ($user->is_staff) {
            abort_unless($student->agent_id === $user->id, 403, 'Unauthorized access');
            return;
        }

        abort(403, 'Unauthorized access');
    }

    private function checkAccess(User $user, Student $student): bool
    {
        if ($user->is_admin || $user->is_admin_staff) return true;

        if ($user->is_agent) {
            $staffIds = User::where('parent_id', $user->id)->where('role', 'staff')->pluck('id');
            return ($student->agent_id === $user->id || $staffIds->contains($student->agent_id));
        }

        if ($user->is_agent_staff) {
            return in_array($student->agent_id, [$user->id, $user->parent_id]);
        }

        if ($user->is_staff) {
            return $student->agent_id === $user->id;
        }

        return false;
    }

    private function denyAgents(): void
    {
        abort_if(Auth::user()->is_agent, 403, 'Agents have read-only CRM access.');
    }
}
