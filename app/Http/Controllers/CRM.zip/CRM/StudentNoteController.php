<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\StudentNote;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class StudentNoteController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'student_id' => 'required|exists:students,id',
            'content' => 'required|string',
            'type' => 'nullable|in:internal,log',
            'is_pinned' => 'nullable|boolean',
            'title' => 'nullable|string|max:255',
        ]);

        $isLog = ($request->input('type') === 'log');

        $note = StudentNote::create([
            'student_id' => $validated['student_id'],
            'content' => $validated['content'],
            'created_by' => Auth::id(),
            'is_pinned' => $request->boolean('is_pinned', false),
            'is_log' => $isLog,
            'title' => $request->input('title') ?? ($isLog ? 'Activity Log' : null),
            'type' => $isLog ? 'internal' : ($request->input('type') ?? 'internal'),
        ]);

        $message = $note->is_log ? 'Activity logged successfully.' : 'Note added successfully.';

        return redirect()->back()->with('success', $message);
    }

    public function update(Request $request, StudentNote $note)
    {
        $this->denyAgents();
        $this->authorizeNote($note);

        $validated = $request->validate([
            'content'            => ['required', 'string'],
            'type'               => ['required', 'in:internal,customer_visible,reminder'],
            'is_pinned'          => ['boolean'],
            'remind_at'          => ['nullable', 'date'],
            'reminder_time_slot' => ['nullable', 'in:morning,day,evening'],
        ]);

        $note->update([
            ...$validated,
            'is_pinned' => $request->boolean('is_pinned'),
        ]);

        return back()->with('success', 'Note updated.');
    }

    public function togglePin(StudentNote $note)
    {
        $this->denyAgents();
        $this->authorizeNote($note);

        $note->togglePin();

        return response()->json(['success' => true, 'is_pinned' => $note->is_pinned]);
    }

    public function destroy(StudentNote $note)
    {
        $this->denyAgents();
        $this->authorizeNote($note);
        $note->delete();

        if (request()->expectsJson()) {
            return response()->json(['success' => true]);
        }

        return back()->with('success', 'Note deleted.');
    }

    private function denyAgents(): void
    {
        abort_if(Auth::user()->is_agent, 403, 'Agents have read-only CRM access.');
    }

    private function authorizeNote(StudentNote $note): void
    {
        $this->authorizeStudentAccess($note->student_id);
    }

    private function authorizeStudentAccess(int $studentId): void
    {
        $user    = Auth::user();
        $student = Student::findOrFail($studentId);

        if ($user->is_admin)       return;
        if ($user->is_admin_staff) return;

        if ($user->is_agent) {
            $staffIds        = User::where('parent_id', $user->id)->where('role', 'staff')->pluck('id')->toArray();
            $allowedAgentIds = array_merge([$user->id], $staffIds);
            abort_unless(in_array($student->agent_id, $allowedAgentIds), 403);
            return;
        }

        if ($user->is_agent_staff) {
            abort_unless(in_array($student->agent_id, [$user->id, $user->parent_id]), 403);
            return;
        }

        if ($user->is_staff) {
            abort_unless($student->agent_id === $user->id, 403);
            return;
        }

        abort(403);
    }
}
