<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\CrmTasks;
use App\Models\Student;
use App\Models\User;
use App\Notifications\CrmTaskNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CrmTasksController extends Controller
{
    // =========================================================================
    // STORE
    // =========================================================================

    public function store(Request $request)
    {
        $this->denyAgents();

        $validated = $request->validate([
            'student_id'  => ['required', 'exists:students,id'],
            'title'       => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'task_type'   => ['required', 'string', 'in:call,email,meeting,whatsapp,todo,follow_up,counseling,document_review'],
            'priority'    => ['required', 'in:low,medium,high'],
            'due_date'    => ['nullable', 'date'],
            'time_slot'   => ['nullable', 'in:morning,afternoon,evening'],
            'assigned_to' => [
                'nullable',
                'exists:users,id',
                function ($attribute, $value, $fail) {
                    if ($value) {
                        $user = User::find($value);
                        if ($user && !$this->isAssignableRole($user)) {
                            $fail('Tasks can only be assigned to Admin or Staff users.');
                        }
                    }
                }
            ],
        ]);

        $this->authorizeStudentAccess((int) $validated['student_id']);

        $assignedTo = $validated['assigned_to'] ?? Auth::id();

        // Double-check assignee role
        if ($assignedTo) {
            $assignee = User::find($assignedTo);
            if (!$assignee || !$this->isAssignableRole($assignee)) {
                abort(403, 'Tasks can only be assigned to Admin or Staff users.');
            }
        }

        $task = CrmTasks::create([
            'student_id'         => $validated['student_id'],
            'subject'            => $validated['title'],
            'description'        => $validated['description'] ?? '',
            'activity_type'      => $validated['task_type'],
            'scheduled_at'       => $validated['due_date'] ?? null,
            'priority_time_slot' => $validated['time_slot'] ?? null,
            'assigned_to'        => $assignedTo,
            'created_by'         => Auth::id(),
            'status'             => 'pending',
            'meta_data'          => json_encode(['priority' => $validated['priority']]),
        ]);
        if ($assignedTo && $assignedTo != Auth::id()) {
            $assignee = User::find($assignedTo);
            if ($assignee) {
                $assignee->notify(new CrmTaskNotification($task, 'assigned'));
            }
        }
        // Log the activity
        $this->logActivity($task->student_id, 'task_created', "Task created: {$task->subject}");

        return redirect()->back()->with('success', 'Task created successfully.');
    }

    // =========================================================================
    // UPDATE
    // =========================================================================

    public function update(Request $request, CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        $validated = $request->validate([
            'title'       => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'task_type'   => ['required', 'string', 'in:call,email,meeting,whatsapp,todo,follow_up,counseling,document_review'],
            'priority'    => ['required', 'in:low,medium,high'],
            'due_date'    => ['nullable', 'date'],
            'time_slot'   => ['nullable', 'in:morning,afternoon,evening'],
            'assigned_to' => [
                'nullable',
                'exists:users,id',
                function ($attribute, $value, $fail) {
                    if ($value) {
                        $user = User::find($value);
                        if ($user && !$this->isAssignableRole($user)) {
                            $fail('Tasks can only be assigned to Admin or Staff users.');
                        }
                    }
                }
            ],
        ]);

        $assignedTo = $validated['assigned_to'] ?? $task->assigned_to;

        if ($assignedTo) {
            $user = User::find($assignedTo);
            if ($user && !$this->isAssignableRole($user)) {
                abort(403, 'Tasks can only be assigned to Admin or Staff users.');
            }
        }

        $metaData = $task->meta_data ? json_decode($task->meta_data, true) : [];
        $metaData['priority'] = $validated['priority'];
        $oldAssignee = $task->assigned_to;

        $task->update([
            'subject'            => $validated['title'],
            'description'        => $validated['description'] ?? '',
            'activity_type'      => $validated['task_type'],
            'scheduled_at'       => $validated['due_date'] ?? null,
            'priority_time_slot' => $validated['time_slot'] ?? null,
            'assigned_to'        => $assignedTo,
            'meta_data'          => json_encode($metaData),
        ]);

        // Log assignment change
        if ($oldAssignee != $assignedTo) {
            $this->logActivity(
                $task->student_id,
                'task_reassigned',
                "Task '{$task->subject}' reassigned from User:{$oldAssignee} to User:{$assignedTo}"
            );
        }

        $this->logActivity($task->student_id, 'task_updated', "Task updated: {$task->subject}");

        return redirect()->back()->with('success', 'Task updated successfully.');
    }

    // =========================================================================
    // COMPLETE - FIXED VERSION
    // =========================================================================

    public function complete(Request $request, CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        // DEBUG: Log all incoming data
        Log::info('Complete method called', [
            'task_id' => $task->id,
            'all_input' => $request->all(),
            'completion_action' => $request->input('completion_action'),
            'next_task_title' => $request->input('next_task_title'),
            'next_due_date' => $request->input('next_due_date'),
        ]);

        $request->validate([
            'completion_note' => ['nullable', 'string'],
            'completion_action' => ['required', 'in:just_complete,create_next'],
            'reassign_to' => ['nullable', 'exists:users,id'],
            'next_task_title' => ['required_if:completion_action,create_next', 'nullable', 'string', 'max:255'],
            'next_due_date' => ['required_if:completion_action,create_next', 'nullable', 'date'],
            'next_task_type' => ['required_if:completion_action,create_next', 'nullable', 'string', 'in:call,email,meeting,whatsapp,todo,follow_up,counseling,document_review'],
            'next_task_description' => ['nullable', 'string'],
            'next_time_slot' => ['nullable', 'in:morning,afternoon,evening'],
            'next_priority' => ['nullable', 'in:low,medium,high'],
            'next_assigned_to' => ['nullable', 'exists:users,id'],
        ]);

        DB::beginTransaction();

        try {
            // Prepare update data
            $updateData = [
                'status' => 'completed',
                'completed_at' => now(),
                'completed_by' => Auth::id(),
                'completion_note' => $request->input('completion_note') ?? 'Task completed',
            ];

            // Handle reassignment if specified and different
            if ($request->filled('reassign_to') && $request->input('reassign_to') != $task->assigned_to) {
                $newAssignee = User::find($request->input('reassign_to'));
                if ($newAssignee && $this->isAssignableRole($newAssignee)) {
                    $updateData['assigned_to'] = $newAssignee->id;
                }
            }

            $task->update($updateData);

            // DEBUG: Log after update
            Log::info('Task updated', ['task_id' => $task->id, 'status' => $task->status]);

            // Create next task if create_next is selected
            if ($request->input('completion_action') === 'create_next') {
                Log::info('Create next task flow started', [
                    'next_task_title' => $request->input('next_task_title'),
                    'next_due_date' => $request->input('next_due_date'),
                ]);

                if ($request->filled('next_task_title') && $request->filled('next_due_date')) {
                    $nextAssignee = $request->input('next_assigned_to') ?? $request->input('reassign_to') ?? $task->assigned_to;

                    $metaData = [
                        'priority' => $request->input('next_priority', 'medium'),
                        'parent_task_id' => $task->id,
                        'created_from_completion' => true,
                    ];

                    $nextTask = CrmTasks::create([
                        'student_id' => $task->student_id,
                        'subject' => $request->input('next_task_title'),
                        'description' => $request->input('next_task_description') ?? 'Follow-up from completed task: ' . $task->subject,
                        'activity_type' => $request->input('next_task_type', 'follow_up'),
                        'scheduled_at' => $request->input('next_due_date'),
                        'priority_time_slot' => $request->input('next_time_slot'),
                        'assigned_to' => $nextAssignee,
                        'created_by' => Auth::id(),
                        'status' => 'pending',
                        'meta_data' => json_encode($metaData),
                    ]);

                    Log::info('Next task created', ['next_task_id' => $nextTask->id]);
                } else {
                    Log::warning('Next task not created - missing title or due date', [
                        'title' => $request->input('next_task_title'),
                        'due_date' => $request->input('next_due_date'),
                    ]);
                }
            }

            DB::commit();

            $message = $request->input('completion_action') === 'create_next'
                ? 'Task completed and follow-up task created successfully.'
                : 'Task marked as completed successfully.';

            return redirect()->back()->with('success', $message);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Task completion failed: ' . $e->getMessage(), [
                'task_id' => $task->id,
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Failed to complete task: ' . $e->getMessage());
        }
    }
    // =========================================================================
    // CANCEL - FIXED VERSION
    // =========================================================================

    public function cancel(Request $request, CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        $request->validate([
            'cancellation_reason' => ['required', 'string', 'min:5'],
        ]);

        DB::beginTransaction();

        try {
            $oldStatus = $task->status;
            $oldAssignee = $task->assigned_to;

            $task->update([
                'status'             => 'cancelled',
                'cancelled_at'       => now(),
                'cancelled_by'       => Auth::id(),
                'cancellation_note'  => $request->input('cancellation_reason'),
            ]);

            $this->logActivity(
                $task->student_id,
                'task_cancelled',
                "Task cancelled: {$task->subject}. Reason: " . substr($request->input('cancellation_reason'), 0, 200)
            );

            DB::commit();

            return redirect()->back()->with('success', 'Task cancelled successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Task cancellation failed: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Failed to cancel task.');
        }
    }

    // =========================================================================
    // RESCHEDULE - IMPROVED VERSION
    // =========================================================================

    public function reschedule(Request $request, CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        $validated = $request->validate([
            'due_date' => ['nullable', 'date'],
            'time_slot' => ['nullable', 'in:morning,afternoon,evening'],
            'assigned_to' => ['nullable', 'exists:users,id'],
            'reschedule_reason' => ['nullable', 'string', 'max:500'],
        ]);

        $oldDate = $task->scheduled_at?->format('Y-m-d');
        $newDate = $validated['due_date'] ?? null;
        $oldAssignee = $task->assigned_to;
        $newAssignee = $validated['assigned_to'] ?? $task->assigned_to;

        // Track changes for logging
        $changes = [];
        if ($oldDate != $newDate) {
            $changes[] = "date from {$oldDate} to {$newDate}";
        }
        if ($oldAssignee != $newAssignee) {
            $newUser = User::find($newAssignee);
            $changes[] = "assignee to {$newUser?->name}";
        }
        if ($validated['time_slot'] && $validated['time_slot'] != $task->priority_time_slot) {
            $changes[] = "time slot to {$validated['time_slot']}";
        }

        $task->update([
            'scheduled_at' => $newDate ?? $task->scheduled_at,
            'priority_time_slot' => $validated['time_slot'] ?? $task->priority_time_slot,
            'assigned_to' => $newAssignee,
        ]);

        // FIX: Handle meta_data properly - it might be array or string
        $metaData = $task->meta_data;

        // If it's a string, decode it; if it's already an array, use it directly
        if (is_string($metaData)) {
            $metaData = json_decode($metaData, true) ?? [];
        } elseif (!is_array($metaData)) {
            $metaData = [];
        }

        // Initialize reschedule_history if not exists
        if (!isset($metaData['reschedule_history'])) {
            $metaData['reschedule_history'] = [];
        }

        // Add to history
        $metaData['reschedule_history'][] = [
            'date' => now()->toDateTimeString(),
            'user_id' => Auth::id(),
            'user_name' => Auth::user()->name,
            'changes' => implode(', ', $changes),
            'reason' => $validated['reschedule_reason'] ?? null,
        ];

        // Store back as JSON
        $task->meta_data = json_encode($metaData);
        $task->save();

        $this->logActivity(
            $task->student_id,
            'task_rescheduled',
            "Task rescheduled: {$task->subject}. Changes: " . implode(', ', $changes)
        );

        $message = 'Task rescheduled successfully.';
        if ($validated['reschedule_reason']) {
            $message .= ' Reason noted.';
        }

        return redirect()->back()->with('success', $message);
    }

    // =========================================================================
    // UNDO COMPLETE
    // =========================================================================

    public function undoComplete(CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        $task->update([
            'status'          => 'pending',
            'completed_at'    => null,
            'completed_by'    => null,
            'completion_note' => null,
        ]);

        $this->logActivity($task->student_id, 'task_reopened', "Task reopened: {$task->subject}");

        return response()->json(['success' => true, 'message' => 'Task reopened successfully.']);
    }

    // =========================================================================
    // UNDO CANCEL
    // =========================================================================

    public function undoCancel(CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        $task->update([
            'status'           => 'pending',
            'cancelled_at'     => null,
            'cancelled_by'     => null,
            'cancellation_note' => null,
        ]);

        $this->logActivity($task->student_id, 'task_restored', "Task restored from cancelled: {$task->subject}");

        return response()->json(['success' => true, 'message' => 'Task restored successfully.']);
    }

    // =========================================================================
    // GET EDIT DATA (AJAX)
    // =========================================================================

    public function getEditData(CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        $metaData = $task->meta_data;

        return response()->json([
            'id' => $task->id,
            'subject' => $task->subject,
            'description' => $task->description,
            'activity_type' => $task->activity_type,
            'scheduled_at' => $task->scheduled_at ? $task->scheduled_at->format('Y-m-d') : null,
            'priority_time_slot' => $task->priority_time_slot,
            'assigned_to' => $task->assigned_to,
            'assignee_name' => $task->assignee?->name,
            'priority' => $metaData['priority'] ?? 'medium',
            'status' => $task->status,
        ]);
    }

    // =========================================================================
    // DELETE
    // =========================================================================

    public function destroy(CrmTasks $task)
    {
        $this->denyAgents();
        $this->authorizeTask($task);

        $studentId = $task->student_id;
        $taskSubject = $task->subject;

        $task->delete();

        $this->logActivity($studentId, 'task_deleted', "Task deleted: {$taskSubject}");

        return redirect()->back()->with('success', 'Task deleted successfully.');
    }

    // =========================================================================
    // BULK ACTIONS (NEW)
    // =========================================================================

    public function bulkComplete(Request $request)
    {
        $this->denyAgents();

        $request->validate([
            'task_ids' => ['required', 'array'],
            'task_ids.*' => ['exists:crm_tasks,id'],
            'completion_note' => ['nullable', 'string'],
        ]);

        $tasks = CrmTasks::whereIn('id', $request->input('task_ids'))
            ->where('status', 'pending')
            ->get();

        $count = 0;
        foreach ($tasks as $task) {
            $this->authorizeTask($task);
            $task->update([
                'status' => 'completed',
                'completed_at' => now(),
                'completed_by' => Auth::id(),
                'completion_note' => $request->input('completion_note') ?? 'Bulk completed',
            ]);
            $count++;
        }

        return redirect()->back()->with('success', "{$count} tasks completed successfully.");
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /**
     * Log activity for a student
     */
    private function logActivity(int $studentId, string $type, string $description): void
    {
        try {
            // You can implement this based on your activity logging system
            // For example, using a CrmActivityLog model:
            // CrmActivityLog::create([
            //     'student_id' => $studentId,
            //     'user_id' => Auth::id(),
            //     'type' => $type,
            //     'description' => $description,
            //     'created_at' => now(),
            // ]);

            // Or just log to Laravel's log for now
            Log::info("CRM Activity: {$type}", [
                'student_id' => $studentId,
                'user_id' => Auth::id(),
                'description' => $description
            ]);
        } catch (\Exception $e) {
            // Don't let logging break the main flow
            Log::warning('Failed to log CRM activity: ' . $e->getMessage());
        }
    }

    private function denyAgents(): void
    {
        if (Auth::user() && Auth::user()->is_agent) {
            abort(403, 'Agents have read-only CRM access.');
        }
    }

    private function authorizeTask(CrmTasks $task): void
    {
        $this->authorizeStudentAccess($task->student_id);
    }

    private function isAssignableRole(User $user): bool
    {
        // Check if user has any assignable role
        return $user->is_admin === true
            || $user->is_staff === true
            || $user->is_admin_staff === true
            || (isset($user->role) && in_array($user->role, ['admin', 'staff', 'admin_staff']));
    }

    private function authorizeStudentAccess(int $studentId): void
    {
        $user = Auth::user();

        // Admin and Admin Staff have full access
        if ($user->is_admin || $user->is_admin_staff) {
            return;
        }

        $student = Student::findOrFail($studentId);

        // Agents can only access their own students and staff under them
        if ($user->is_agent) {
            $staffIds = User::where('parent_id', $user->id)
                ->where(function ($q) {
                    $q->where('role', 'staff')->orWhere('is_staff', true);
                })
                ->pluck('id')
                ->toArray();
            $allowedAgentIds = array_merge([$user->id], $staffIds);

            if (!in_array($student->agent_id, $allowedAgentIds)) {
                abort(403, 'You do not have access to this student.');
            }
            return;
        }

        // Agent staff can access their own students
        if ($user->is_agent_staff) {
            if (!in_array($student->agent_id, [$user->id, $user->parent_id])) {
                abort(403, 'You do not have access to this student.');
            }
            return;
        }

        // Staff can access students assigned to them
        if ($user->is_staff) {
            if ($student->agent_id !== $user->id) {
                abort(403, 'You do not have access to this student.');
            }
            return;
        }

        abort(403, 'Unauthorized access.');
    }
}
