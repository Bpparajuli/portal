<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\StudentStage;
use App\Models\CrmTasks;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use App\Models\Activity; // Add this at the top if you have an Activity model

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $user = Auth::user();
        $agents = User::where('role', 'agent')->orderBy('name')->get();
        $query = Student::with([
            'currentStage',
            'agent',
            'upcomingActivities',
            'overdueActivities',
            'pendingActivities',
        ])->accessible();

        // Search filter
        if ($request->filled('search')) {
            $search = trim($request->search);
            $type = $request->search_type ?? 'all';

            $query->where(function ($q) use ($search, $type) {
                // ALL
                if ($type === 'all') {
                    $q->where('first_name', 'like', "%{$search}%")
                        ->orWhere('last_name', 'like', "%{$search}%")
                        ->orWhere('phone_number', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('preferred_country', 'like', "%{$search}%")
                        ->orWhere('tags', 'like', "%{$search}%");
                }

                // NAME
                if ($type === 'name') {
                    $q->where('first_name', 'like', "%{$search}%")
                        ->orWhere('last_name', 'like', "%{$search}%");
                }

                // PHONE
                if ($type === 'phone_number' || $type === 'phone') {
                    $q->where('phone_number', 'like', "%{$search}%");
                }

                // EMAIL
                if ($type === 'email') {
                    $q->where('email', 'like', "%{$search}%");
                }

                // TAG
                if ($type === 'tag') {
                    $q->where('tags', 'like', "%{$search}%");
                }

                // COUNTRY
                if ($type === 'country' || $type === 'preferred_country') {
                    $q->where('preferred_country', 'like', "%{$search}%");
                }

                // DEGREE
                if ($type === 'degree') {
                    $q->where('degree_level', 'like', "%{$search}%");
                }

                // UNIVERSITY
                if ($type === 'university') {
                    $q->whereHas('applications.university', function ($uni) use ($search) {
                        $uni->where('name', 'like', "%{$search}%");
                    });
                }
            });
        }

        // Stage filter
        if ($request->filled('stage_id')) {
            $query->byStage($request->stage_id);
        }

        // Assignee filter - ONLY STAFF users
        if ($request->filled('assignee_id')) {
            if ($user->is_admin || $user->is_admin_staff) {
                $query->where('agent_id', $request->assignee_id);
            } elseif ($user->is_agent) {
                $staffIds = User::where('parent_id', $user->id)->where('role', 'staff')->pluck('id')->toArray();
                if (in_array($request->assignee_id, $staffIds)) {
                    $query->where('agent_id', $request->assignee_id);
                }
            }
        }

        // Activity filter
        if ($request->filled('activity_filter')) {
            if ($request->activity_filter === 'overdue') {
                $query->whereHas('overdueActivities');
            }
            if ($request->activity_filter === 'today') {
                $query->whereHas('pendingActivities', function ($q) {
                    $q->whereDate('scheduled_at', today())->where('status', 'pending');
                });
            }
            if ($request->activity_filter === 'upcoming') {
                $query->whereHas('upcomingActivities');
            }
        }

        // View type
        $view = $request->get('view', 'kanban');

        if ($view === 'kanban') {
            $students = $query->get()->groupBy('current_stage_id');
        } else {
            $students = $query->latest()->paginate(25)->withQueryString();
        }

        // Stages
        $stages = StudentStage::active()->ordered()->get();

        // Assignee dropdown - ONLY STAFF members
        $assignees = collect();

        if ($user->is_admin || $user->is_admin_staff) {
            $assignees = User::where('role', 'staff')->select('id', 'name')->orderBy('name')->get();
        } elseif ($user->is_agent) {
            $assignees = User::where('parent_id', $user->id)->where('role', 'staff')->select('id', 'name')->orderBy('name')->get();
        }

        // Dashboard stats
        $accessibleStudentIds = Student::accessible()->pluck('id');

        if ($user->is_staff) {
            $taskBase = CrmTasks::where(function ($q) use ($accessibleStudentIds, $user) {
                $q->whereIn('student_id', $accessibleStudentIds)->orWhere('assigned_to', $user->id);
            });
        } else {
            $taskBase = CrmTasks::whereIn('student_id', $accessibleStudentIds);
        }

        $stats = [
            'total' => $accessibleStudentIds->count(),
            'my_students' => CrmTasks::where('assigned_to', $user->id)->whereNotNull('student_id')->distinct()->count('student_id'),
            'today' => (clone $taskBase)->whereDate('scheduled_at', today())->where('status', 'pending')->count(),
            'overdue' => (clone $taskBase)->whereDate('scheduled_at', '<', today())->where('status', 'pending')->count(),
            'upcoming' => (clone $taskBase)->whereDate('scheduled_at', '>', today())->where('status', 'pending')->count(),
        ];

        // FIXED: Removed 'request' from compact
        return view('crm.dashboard', compact('students', 'stages', 'assignees', 'stats', 'view', 'user', 'agents'));
    }

    public function updateStage(Request $request, Student $student)
    {
        try {
            $request->validate([
                'stage_id' => 'required|exists:student_stages,id',
            ]);

            $user = Auth::user();

            // Check access
            $hasAccess = false;
            if ($user->is_admin || $user->is_admin_staff) {
                $hasAccess = true;
            } elseif ($user->is_agent) {
                $staffIds = User::where('parent_id', $user->id)->where('role', 'staff')->pluck('id')->toArray();
                $allowedAgentIds = array_merge([$user->id], $staffIds);
                $hasAccess = in_array($student->agent_id, $allowedAgentIds);
            } elseif ($user->is_agent_staff) {
                $hasAccess = in_array($student->agent_id, [$user->id, $user->parent_id]);
            } elseif ($user->is_staff) {
                $hasAccess = $student->agent_id === $user->id;
            }

            if (!$hasAccess) {
                return response()->json(['success' => false, 'error' => 'Unauthorized'], 403);
            }

            $student->update(['current_stage_id' => $request->stage_id]);

            return response()->json([
                'success' => true,
                'message' => 'Stage updated successfully',
                'student' => $student->fresh('currentStage')
            ]);
        } catch (\Exception $e) {
            Log::error('Error updating stage: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => 'Failed to update stage'], 500);
        }
    }

    public function addTag(Request $request, Student $student)
    {
        try {
            $request->validate(['tag' => 'required|string|max:50']);

            $user = Auth::user();
            if (!$this->canAccess($user, $student)) {
                return response()->json(['success' => false, 'error' => 'Unauthorized'], 403);
            }

            $currentTags = $student->tags ?? [];
            $newTag = trim($request->tag);

            if (!in_array($newTag, $currentTags)) {
                $currentTags[] = $newTag;
                $student->tags = $currentTags;
                $student->save();
            }

            return response()->json(['success' => true, 'tags' => $currentTags]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function removeTag(Request $request, Student $student)
    {
        try {
            $request->validate(['tag' => 'required|string']);

            $user = Auth::user();
            if (!$this->canAccess($user, $student)) {
                return response()->json(['success' => false, 'error' => 'Unauthorized'], 403);
            }

            $currentTags = $student->tags ?? [];
            $tagToRemove = $request->tag;
            $currentTags = array_values(array_filter($currentTags, function ($tag) use ($tagToRemove) {
                return $tag !== $tagToRemove;
            }));

            $student->tags = $currentTags;
            $student->save();

            return response()->json(['success' => true, 'tags' => $currentTags]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function getPopularTags()
    {
        try {
            $students = Student::accessible()->get();
            $allTags = [];
            foreach ($students as $student) {
                if ($student->tags && is_array($student->tags)) {
                    $allTags = array_merge($allTags, $student->tags);
                }
            }
            $tagCounts = array_count_values($allTags);
            arsort($tagCounts);
            return response()->json(['tags' => array_slice(array_keys($tagCounts), 0, 10)]);
        } catch (\Exception $e) {
            return response()->json(['tags' => []], 200);
        }
    }

    // FIXED: Added proper AJAX handling for rating updates
    public function updateRating(Request $request, $id)
    {
        try {
            $request->validate(['rating' => 'nullable|integer|min:1|max:3']);
            $student = Student::findOrFail($id);

            $user = Auth::user();
            if (!$this->canAccess($user, $student)) {
                if ($request->ajax()) {
                    return response()->json(['success' => false, 'error' => 'Unauthorized'], 403);
                }
                return back()->with('error', 'Unauthorized');
            }

            $student->rating = $request->rating;
            $student->save();

            if ($request->ajax()) {
                return response()->json(['success' => true, 'message' => 'Rating updated successfully']);
            }

            return back()->with('success', 'Rating updated successfully.');
        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
            }
            return back()->with('error', 'Failed to update rating');
        }
    }

    public function export(Request $request)
    {
        $query = Student::with('currentStage', 'agent')->accessible();
        if ($request->filled('stage_id')) {
            $query->byStage($request->stage_id);
        }
        $students = $query->get();

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="crm-students-' . now()->format('Y-m-d') . '.csv"',
        ];

        $callback = function () use ($students) {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, ['ID', 'Name', 'Email', 'Phone', 'Stage', 'Staff', 'Tags', 'Created At']);
            foreach ($students as $s) {
                fputcsv($handle, [
                    $s->id,
                    $s->full_name,
                    $s->email ?? '—',
                    $s->phone_number ?? '—',
                    $s->currentStage?->name ?? '—',
                    $s->agent?->name ?? '—',
                    implode(', ', $s->tags ?? []),
                    $s->created_at->format('Y-m-d H:i:s'),
                ]);
            }
            fclose($handle);
        };

        return response()->stream($callback, 200, $headers);
    }

    public function show(Student $student)
    {
        $user = Auth::user();
        abort_unless($this->canAccess($user, $student), 403);
        $student->load([
            'agent',
            'currentStage',
            'activities' => fn($q) => $q->latest()->limit(20),
            'notes' => fn($q) => $q->latest()
        ]);
        $stages = StudentStage::active()->ordered()->get();

        $assignableUsers = User::whereIn('role', ['admin', 'staff', 'admin_staff'])
            ->orderBy('name')
            ->get(['id', 'name', 'role']);

        return view('crm.student-show', compact('student', 'assignableUsers', 'stages', 'user'));
    }

    private function canAccess(User $user, Student $student): bool
    {
        if ($user->is_admin || $user->is_admin_staff) return true;
        if ($user->is_agent) {
            $staffIds = User::where('parent_id', $user->id)->where('role', 'staff')->pluck('id')->toArray();
            $allowedAgentIds = array_merge([$user->id], $staffIds);
            return in_array($student->agent_id, $allowedAgentIds);
        }
        if ($user->is_agent_staff) return in_array($student->agent_id, [$user->id, $user->parent_id]);
        if ($user->is_staff) return $student->agent_id === $user->id;
        return false;
    }


    /**
     * Get calendar events for FullCalendar
     */
    public function getCalendarEvents(Request $request)
    {
        try {
            $start = Carbon::parse($request->start);
            $end = Carbon::parse($request->end);

            Log::info('Calendar events requested', [
                'start' => $start->toDateString(),
                'end' => $end->toDateString(),
                'filters' => $request->filters
            ]);

            $user = Auth::user();

            // Base query for tasks
            $query = CrmTasks::with('student')
                ->where('status', 'pending')
                ->whereNotNull('scheduled_at')
                ->whereBetween('scheduled_at', [$start, $end]);

            // Apply user access restrictions
            if (!$user->is_admin && !$user->is_admin_staff) {
                if ($user->is_agent) {
                    $staffIds = User::where('parent_id', $user->id)->where('role', 'staff')->pluck('id')->toArray();
                    $allowedUserIds = array_merge([$user->id], $staffIds);
                    $query->whereIn('assigned_to', $allowedUserIds);
                } elseif ($user->is_staff) {
                    $query->where('assigned_to', $user->id);
                }
            }

            // Apply filters from request
            $filters = $request->filters ?? [];

            if (!empty($filters['assignee_id'])) {
                $query->where('assigned_to', $filters['assignee_id']);
            }

            // Student-related filters (search, stage)
            if (!empty($filters['search']) || !empty($filters['stage_id'])) {
                $studentsQuery = Student::query();

                if (!empty($filters['search'])) {
                    $search = $filters['search'];
                    $searchType = $filters['search_type'] ?? 'all';

                    if ($searchType == 'all' || $searchType == 'name') {
                        $studentsQuery->where(function ($q) use ($search) {
                            $q->where('first_name', 'like', "%{$search}%")
                                ->orWhere('last_name', 'like', "%{$search}%");
                        });
                    }
                    if ($searchType == 'phone' || $searchType == 'phone_number') {
                        $studentsQuery->where('phone_number', 'like', "%{$search}%");
                    }
                    if ($searchType == 'email') {
                        $studentsQuery->where('email', 'like', "%{$search}%");
                    }
                }

                if (!empty($filters['stage_id'])) {
                    $studentsQuery->where('current_stage_id', $filters['stage_id']);
                }

                $studentIds = $studentsQuery->pluck('id')->toArray();

                if (empty($studentIds)) {
                    return response()->json(['success' => true, 'events' => []]);
                }

                $query->whereIn('student_id', $studentIds);
            }

            // Activity filter
            if (!empty($filters['activity_filter'])) {
                $today = now()->startOfDay();
                if ($filters['activity_filter'] === 'overdue') {
                    $query->whereDate('scheduled_at', '<', $today);
                }
                if ($filters['activity_filter'] === 'today') {
                    $query->whereDate('scheduled_at', $today);
                }
                if ($filters['activity_filter'] === 'upcoming') {
                    $query->whereDate('scheduled_at', '>', $today);
                }
            }

            $tasks = $query->get();

            Log::info('Found tasks', ['count' => $tasks->count()]);

            $events = [];

            foreach ($tasks as $task) {
                $eventDate = Carbon::parse($task->scheduled_at);

                // FIXED: Handle meta_data properly - it might be string or array
                $metaData = [];
                if ($task->meta_data) {
                    if (is_string($task->meta_data)) {
                        $metaData = json_decode($task->meta_data, true) ?: [];
                    } elseif (is_array($task->meta_data)) {
                        $metaData = $task->meta_data;
                    }
                }
                $priority = $metaData['priority'] ?? 'medium';

                // Determine status and color
                $now = now();
                if ($eventDate->lt($now)) {
                    $status = 'overdue';
                    $color = '#ef4444';
                } elseif ($eventDate->isToday()) {
                    $status = 'today';
                    $color = '#f59e0b';
                } else {
                    $status = 'upcoming';
                    // Priority-based color for upcoming
                    $color = $priority == 'high' ? '#dc2626' : ($priority == 'medium' ? '#f59e0b' : '#10b981');
                }

                $events[] = [
                    'id' => $task->id,
                    'title' => $task->subject ?? $task->activity_type ?? 'Task',
                    'start' => $eventDate->toIso8601String(),
                    'end' => $eventDate->copy()->addHour()->toIso8601String(),
                    'backgroundColor' => $color,
                    'borderColor' => $color,
                    'extendedProps' => [
                        'student_id' => $task->student_id,
                        'student_name' => $task->student?->full_name ?? 'Unknown',
                        'activity_id' => $task->id,
                        'activity_type' => $task->activity_type ?? 'Task',
                        'description' => $task->description ?? 'No description',
                        'priority' => $priority,
                        'status' => $status,
                        'status_label' => ucfirst($status)
                    ]
                ];
            }

            // Add helpful message if no events
            if (empty($events)) {
                $hasAnyTasks = CrmTasks::whereNotNull('scheduled_at')->exists();

                if (!$hasAnyTasks) {
                    $message = 'No tasks with dates found. Create a task with a due date from the student profile.';
                } else {
                    $message = 'No pending tasks in this date range. Try changing the calendar view or creating new tasks.';
                }

                $events[] = [
                    'id' => 'info_' . time(),
                    'title' => '📌 ' . $message,
                    'start' => now()->toIso8601String(),
                    'end' => now()->addHour()->toIso8601String(),
                    'backgroundColor' => '#6b7280',
                    'borderColor' => '#6b7280',
                    'display' => 'background',
                    'extendedProps' => [
                        'student_id' => null,
                        'student_name' => 'System',
                        'activity_type' => 'Info',
                        'description' => $message,
                        'status' => 'info',
                        'status_label' => 'Info'
                    ]
                ];
            }

            return response()->json(['success' => true, 'events' => $events]);
        } catch (\Exception $e) {
            Log::error('Calendar error: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
